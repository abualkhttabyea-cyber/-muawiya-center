
"use client";

import { useState, useEffect } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Camera, Save, Shield, Mail, User, Phone } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { maskEmail } from '@/lib/constants';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import Image from 'next/image';
import { useFirestore, useUser } from '@/firebase';
import { doc, getDoc, updateDoc } from 'firebase/firestore';

export default function ProfilePage() {
  const { toast } = useToast();
  const db = useFirestore();
  const { user } = useUser();
  const logoData = PlaceHolderImages.find(img => img.id === 'center-logo');
  const defaultLogo = logoData?.imageUrl || "https://picsum.photos/seed/muawiya-official-logo/800/800";

  const [profile, setProfile] = useState({
    name: 'جاري التحميل...',
    phone: '',
    email: '',
    photoUrl: '' 
  });

  useEffect(() => {
    async function loadProfile() {
      if (user && db) {
        const docRef = doc(db, 'users', user.uid);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = docSnap.data();
          setProfile({
            name: data.name || '',
            phone: data.phone || '',
            email: user.email || '',
            photoUrl: data.photoUrl || ''
          });
        }
      }
    }
    loadProfile();
  }, [user, db]);

  const handleSave = async () => {
    if (user && db) {
      const docRef = doc(db, 'users', user.uid);
      await updateDoc(docRef, {
        name: profile.name,
        phone: profile.phone,
        photoUrl: profile.photoUrl
      });
      toast({
        title: "تم تحديث البيانات",
        description: "تم حفظ تغييرات ملفك الشخصي بنجاح في السحابة.",
      });
    }
  };

  const handlePhotoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => {
        setProfile(prev => ({ ...prev, photoUrl: reader.result as string }));
        toast({
          title: "تم اختيار الصورة",
          description: "اضغط على حفظ التغييرات لتثبيت الصورة الجديدة.",
        });
      };
      reader.readAsDataURL(file);
    }
  };

  return (
    <DashboardShell userRole="ADMIN">
      <div className="max-w-5xl mx-auto space-y-10">
        <header className="space-y-2">
          <h1 className="text-4xl font-black text-primary">إعدادات الملف الشخصي</h1>
          <p className="text-muted-foreground text-lg">إدارة هويتك الرقمية ومعلومات التواصل في مركز معاوية</p>
        </header>

        <div className="grid grid-cols-1 lg:grid-cols-12 gap-10">
          <Card className="lg:col-span-4 bg-card/30 backdrop-blur-xl border-border/50 rounded-[2.5rem] overflow-hidden">
            <CardContent className="pt-12 flex flex-col items-center">
              <div className="relative group">
                <div className="w-48 h-48 flex items-center justify-center bg-transparent">
                  <Image 
                    src={profile.photoUrl || defaultLogo} 
                    alt="Profile" 
                    width={192}
                    height={192}
                    className="w-full h-full object-contain select-none"
                    onContextMenu={(e) => e.preventDefault()}
                    priority
                  />
                </div>
                <Label 
                  htmlFor="photo-upload"
                  className="absolute -bottom-3 -right-3 bg-primary text-primary-foreground p-3 rounded-2xl shadow-xl hover:scale-110 transition-transform active:scale-95 cursor-pointer"
                >
                  <Camera className="size-6" />
                  <input 
                    id="photo-upload" 
                    type="file" 
                    className="hidden" 
                    accept="image/*" 
                    onChange={handlePhotoChange}
                  />
                </Label>
              </div>
              
              <div className="text-center mt-8">
                <h3 className="text-2xl font-black text-foreground">{profile.name}</h3>
                <div className="inline-flex items-center gap-2 mt-2 px-4 py-1.5 bg-primary/10 rounded-full">
                  <Shield className="size-4 text-primary" />
                  <span className="text-primary font-bold text-xs uppercase tracking-widest">المشرف العام</span>
                </div>
              </div>
              
              <div className="w-full mt-10 space-y-4 px-4">
                <div className="flex items-center justify-between p-4 bg-muted/20 rounded-2xl border border-border/30">
                  <div className="flex items-center gap-3">
                    <Mail className="size-4 text-primary" />
                    <span className="text-xs font-bold text-muted-foreground">البريد</span>
                  </div>
                  <span className="text-xs font-mono" dir="ltr">{maskEmail(profile.email)}</span>
                </div>
                <div className="flex items-center justify-between p-4 bg-muted/20 rounded-2xl border border-border/30">
                  <div className="flex items-center gap-3">
                    <Phone className="size-4 text-primary" />
                    <span className="text-xs font-bold text-muted-foreground">الجوال</span>
                  </div>
                  <span className="text-xs font-mono" dir="ltr">{profile.phone}</span>
                </div>
              </div>
            </CardContent>
          </Card>

          <Card className="lg:col-span-8 bg-card/30 backdrop-blur-xl border-border/50 rounded-[2.5rem]">
            <CardHeader className="p-8 border-b border-border/30">
              <CardTitle className="text-xl font-bold flex items-center gap-3">
                <User className="size-6 text-primary" />
                المعلومات الشخصية
              </CardTitle>
            </CardHeader>
            <CardContent className="p-8 space-y-8">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-8">
                <div className="space-y-3">
                  <Label htmlFor="display-name" className="text-muted-foreground font-bold">اسم العرض</Label>
                  <Input 
                    id="display-name" 
                    value={profile.name} 
                    onChange={(e) => setProfile(prev => ({ ...prev, name: e.target.value }))}
                    className="rounded-2xl bg-background/50 border-border/50 h-14 focus:border-primary/50 text-lg"
                  />
                </div>

                <div className="space-y-3">
                  <Label htmlFor="phone-number" className="text-muted-foreground font-bold">رقم الجوال</Label>
                  <Input 
                    id="phone-number" 
                    value={profile.phone} 
                    onChange={(e) => setProfile(prev => ({ ...prev, phone: e.target.value }))}
                    className="rounded-2xl bg-background/50 border-border/50 h-14 focus:border-primary/50 text-lg text-left"
                    dir="ltr"
                  />
                </div>
              </div>

              <div className="space-y-3 opacity-50 cursor-not-allowed">
                <Label className="text-muted-foreground font-bold">البريد الإلكتروني (أساسي - لا يمكن تغييره)</Label>
                <div className="relative">
                  <Input 
                    value={profile.email} 
                    disabled 
                    className="rounded-2xl bg-muted/30 border-border/50 h-14 text-left font-mono" 
                    dir="ltr"
                  />
                  <Shield className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-primary/50" />
                </div>
              </div>

              <div className="pt-6 border-t border-border/30">
                <Button onClick={handleSave} className="w-full md:w-auto px-12 bg-primary text-primary-foreground h-16 rounded-2xl font-black text-lg shadow-lg shadow-primary/20 hover:scale-105 transition-all">
                  <Save className="size-5 ml-3" />
                  حفظ التغييرات النهائية
                </Button>
              </div>
            </CardContent>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}
