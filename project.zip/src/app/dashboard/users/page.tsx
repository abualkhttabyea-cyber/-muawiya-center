
"use client";

import { useState, useMemo } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Users, UserPlus, SearchX, Trash2, Mail, User as UserIcon, GraduationCap, Loader2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { Badge } from '@/components/ui/badge';
import { useFirestore, useCollection } from '@/firebase';
import { collection, addDoc, deleteDoc, doc } from 'firebase/firestore';

export default function UsersPage() {
  const { toast } = useToast();
  const db = useFirestore();
  
  const usersRef = useMemo(() => db ? collection(db, 'users') : null, [db]);
  const { data: users, loading } = useCollection(usersRef);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [adding, setAdding] = useState(false);
  const [search, setSearch] = useState('');
  const [newUser, setNewUser] = useState({ name: '', email: '', role: 'STUDENT' as const });

  const handleAddUser = async () => {
    if (!newUser.name || !db) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى إدخال اسم المستخدم" });
      return;
    }

    setAdding(true);
    try {
      await addDoc(collection(db, 'users'), {
        ...newUser,
        approved: true,
        roleAr: newUser.role === 'TEACHER' ? 'معلم' : 'طالب',
        createdAt: new Date().toISOString()
      });

      setIsAddOpen(false);
      setNewUser({ name: '', email: '', role: 'STUDENT' });
      toast({ title: "تمت الإضافة", description: "تمت إضافة المستخدم وتفعيله في السحابة." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل إضافة المستخدم." });
    } finally {
      setAdding(false);
    }
  };

  const handleDeleteUser = (id: string) => {
    if (!db) return;
    deleteDoc(doc(db, 'users', id));
    toast({ title: "تم الحذف", description: "تم حذف المستخدم من السحابة." });
  };

  const filteredUsers = (users || []).filter((u: any) => 
    u.name?.toLowerCase().includes(search.toLowerCase()) || 
    u.email?.toLowerCase().includes(search.toLowerCase())
  );

  return (
    <DashboardShell userRole="ADMIN">
      <div className="space-y-8">
        <header className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-black text-primary">إدارة الكادر والطلاب</h1>
            <p className="text-muted-foreground mt-1">إضافة، حذف، والتحكم في حسابات المستخدمين سحابياً</p>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-accent text-accent-foreground rounded-xl shadow-lg">
                <UserPlus className="size-4 ml-2" />
                إضافة مستخدم يدوياً
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border rounded-3xl">
              <DialogHeader>
                <DialogTitle className="text-primary font-black">إضافة مستخدم جديد</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4 text-right" dir="rtl">
                <div className="space-y-2">
                  <Label>الاسم الكامل</Label>
                  <Input 
                    value={newUser.name}
                    onChange={(e) => setNewUser({...newUser, name: e.target.value})}
                    placeholder="اسم المستخدم"
                    className="rounded-xl bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>البريد الإلكتروني (اختياري)</Label>
                  <Input 
                    value={newUser.email}
                    onChange={(e) => setNewUser({...newUser, email: e.target.value})}
                    placeholder="example@muawiya.edu"
                    className="rounded-xl bg-background/50 text-left"
                    dir="ltr"
                  />
                </div>
                <div className="space-y-2">
                  <Label>نوع الحساب</Label>
                  <Select 
                    value={newUser.role}
                    onValueChange={(v: 'TEACHER' | 'STUDENT') => setNewUser({...newUser, role: v})}
                  >
                    <SelectTrigger className="rounded-xl bg-background/50">
                      <SelectValue placeholder="اختر الدور" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="TEACHER">معلم حلقة</SelectItem>
                      <SelectItem value="STUDENT">طالب</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAddUser} disabled={adding} className="w-full bg-primary text-primary-foreground rounded-xl font-bold">
                  {adding ? <Loader2 className="animate-spin" /> : "إضافة المستخدم سحابياً"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        <div className="relative">
          <Input 
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="rounded-2xl h-14 bg-card/50 border-border/50 pr-12 focus:border-primary text-right" 
            placeholder="البحث بالاسم أو البريد..." 
          />
          <Users className="absolute right-4 top-1/2 -translate-y-1/2 size-5 text-muted-foreground" />
        </div>

        {loading ? (
          <div className="text-center py-20 text-muted-foreground">جاري تحميل البيانات من السحابة...</div>
        ) : filteredUsers.length === 0 ? (
          <Card className="bg-card/20 border-2 border-dashed border-border rounded-[2.5rem] py-20 flex flex-col items-center justify-center">
            <SearchX className="size-20 text-muted/20 mb-6" />
            <h2 className="text-2xl font-black text-muted-foreground">لا يوجد مستخدمون حالياً</h2>
          </Card>
        ) : (
          <div className="grid grid-cols-1 gap-4">
            {filteredUsers.map((user: any) => (
              <Card key={user.id} className="bg-card/50 border-border rounded-2xl overflow-hidden hover:border-primary/30 transition-all">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center">
                      {user.role === 'TEACHER' ? <GraduationCap className="size-6 text-primary" /> : <UserIcon className="size-6 text-accent" />}
                    </div>
                    <div className="text-right">
                      <div className="flex items-center gap-2">
                        <h3 className="font-bold">{user.name}</h3>
                        <Badge variant="outline" className="text-[10px] border-primary/20 text-primary uppercase">
                          {user.roleAr}
                        </Badge>
                      </div>
                      <div className="flex items-center gap-2 text-xs text-muted-foreground mt-1">
                        <Mail className="size-3" />
                        <span dir="ltr">{user.email || 'بدون بريد'}</span>
                      </div>
                    </div>
                  </div>
                  <Button 
                    onClick={() => handleDeleteUser(user.id)}
                    variant="ghost" 
                    className="text-destructive hover:bg-destructive/10 rounded-xl"
                  >
                    <Trash2 className="size-5" />
                  </Button>
                </CardContent>
              </Card>
            ))}
          </div>
        )}
      </div>
    </DashboardShell>
  );
}
