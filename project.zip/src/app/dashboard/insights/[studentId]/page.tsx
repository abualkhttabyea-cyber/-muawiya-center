
"use client";

import { useEffect, useState, useMemo } from 'react';
import { useParams } from 'next/navigation';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Sparkles, 
  Lightbulb, 
  CheckCircle2, 
  Target,
  RefreshCcw,
  BookOpen,
  History,
  AlertCircle
} from 'lucide-react';
import { studentPerformanceInsight, type StudentPerformanceInsightOutput } from '@/ai/flows/student-performance-insight';
import { Skeleton } from '@/components/ui/skeleton';
import { useFirestore, useCollection, useDoc } from '@/firebase';
import { collection, query, where, doc } from 'firebase/firestore';

export default function StudentInsightPage() {
  const { studentId } = useParams();
  const db = useFirestore();
  
  const [analyzing, setAnalyzing] = useState(false);
  const [insight, setInsight] = useState<StudentPerformanceInsightOutput | null>(null);

  const studentRef = useMemo(() => db ? doc(db, 'users', studentId as string) : null, [db, studentId]);
  const { data: student } = useDoc(studentRef);

  const logsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'logs'), where('studentId', '==', studentId));
  }, [db, studentId]);
  
  const { data: logs, loading: logsLoading } = useCollection(logsQuery);

  const runAnalysis = async () => {
    if (!logs || !student) return;
    
    setAnalyzing(true);
    try {
      const memorizationLogs = logs
        .filter((l: any) => l.type === 'MEMORIZATION')
        .map((l: any) => ({
          date: l.date?.split('T')[0] || '',
          surah: l.surah,
          ayahRange: l.ayahRange,
          grade: l.grade
        }));

      const revisionLogs = logs
        .filter((l: any) => l.type === 'REVISION')
        .map((l: any) => ({
          date: l.date?.split('T')[0] || '',
          surah: l.surah,
          ayahRange: l.ayahRange,
          grade: l.grade
        }));

      const result = await studentPerformanceInsight({
        studentName: student.name || 'طالب',
        memorizationLogs,
        revisionLogs
      });
      setInsight(result);
    } catch (err) {
      console.error(err);
    } finally {
      setAnalyzing(false);
    }
  };

  useEffect(() => {
    if (logs && student && !logsLoading) {
      runAnalysis();
    }
  }, [logs, student, logsLoading]);

  return (
    <DashboardShell userRole="TEACHER">
      <div className="space-y-8 max-w-5xl mx-auto">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <div className="w-16 h-16 bg-primary/20 rounded-2xl flex items-center justify-center text-primary shadow-[0_0_20px_rgba(234,179,8,0.2)]">
              <Sparkles className="size-8" />
            </div>
            <div>
              <h1 className="text-3xl font-black text-primary">تحليل الأداء الذكي (GenAI)</h1>
              <p className="text-muted-foreground">جاري استخراج الخلاصات من السحابة للطالب: {student?.name || '...'}</p>
            </div>
          </div>
          <Button 
            variant="outline" 
            onClick={runAnalysis}
            disabled={analyzing}
            className="border-primary/20 text-primary hover:bg-primary/10 rounded-xl"
          >
            {analyzing ? <RefreshCcw className="size-4 ml-2 animate-spin" /> : <RefreshCcw className="size-4 ml-2" />}
            تحديث التحليل
          </Button>
        </header>

        {(logsLoading || analyzing) ? (
          <div className="space-y-6">
            <Skeleton className="h-40 w-full rounded-2xl bg-card" />
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <Skeleton className="h-60 rounded-2xl bg-card" />
              <Skeleton className="h-60 rounded-2xl bg-card" />
            </div>
          </div>
        ) : insight ? (
          <div className="grid grid-cols-1 md:grid-cols-12 gap-6 fade-slide-in">
            <Card className="md:col-span-12 bg-primary/5 border-primary/20 rounded-2xl overflow-hidden">
              <CardHeader className="pb-0">
                <CardTitle className="text-xl font-bold flex items-center gap-2 text-primary">
                  <Lightbulb className="size-6" />
                  الملخص العام للأداء (تحليل AI)
                </CardTitle>
              </CardHeader>
              <CardContent className="pt-4 pb-6">
                <p className="text-lg leading-relaxed text-foreground/90 font-medium">
                  {insight.overallPerformanceSummary}
                </p>
              </CardContent>
            </Card>

            <Card className="md:col-span-6 bg-card/50 border-border rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2 text-primary">
                  <BookOpen className="size-5" />
                  أبرز نقاط الحفظ
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {insight.memorizationHighlights.map((point, i) => (
                    <li key={i} className="flex gap-3 text-sm">
                      <CheckCircle2 className="size-4 text-primary shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="md:col-span-6 bg-card/50 border-border rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2 text-primary">
                  <History className="size-5" />
                  أبرز نقاط المراجعة
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {insight.revisionHighlights.map((point, i) => (
                    <li key={i} className="flex gap-3 text-sm">
                      <CheckCircle2 className="size-4 text-primary shrink-0 mt-0.5" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="md:col-span-6 bg-accent/5 border-accent/20 rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2 text-accent">
                  <Target className="size-5" />
                  توصيات الدعم والتطوير
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {insight.supportRecommendations.map((point, i) => (
                    <li key={i} className="flex gap-3 text-sm">
                      <div className="w-1.5 h-1.5 rounded-full bg-accent mt-2 shrink-0" />
                      <span>{point}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>

            <Card className="md:col-span-6 bg-primary/10 border-primary/20 rounded-2xl">
              <CardHeader>
                <CardTitle className="text-lg font-bold flex items-center gap-2 text-primary">
                  <AwardIcon className="size-5" />
                  نقاط التميز والثناء
                </CardTitle>
              </CardHeader>
              <CardContent>
                <ul className="space-y-3">
                  {insight.commendations.map((point, i) => (
                    <li key={i} className="flex gap-3 text-sm">
                      <Sparkles className="size-4 text-primary shrink-0 mt-0.5" />
                      <span className="font-semibold">{point}</span>
                    </li>
                  ))}
                </ul>
              </CardContent>
            </Card>
          </div>
        ) : (
          <div className="text-center py-20 bg-card/10 rounded-3xl border border-dashed border-border">
            <AlertCircle className="size-16 text-muted-foreground/30 mx-auto mb-4" />
            <p className="text-muted-foreground font-bold">لا توجد سجلات كافية في السحابة لإجراء التحليل حالياً.</p>
            <p className="text-xs text-muted-foreground/60 mt-2">قم بتسجيل حفظ أو مراجعة للطالب أولاً.</p>
          </div>
        )}
      </div>
    </DashboardShell>
  );
}

function AwardIcon({ className }: { className?: string }) {
  return (
    <svg 
      className={className}
      xmlns="http://www.w3.org/2000/svg" 
      width="24" height="24" 
      viewBox="0 0 24 24" fill="none" 
      stroke="currentColor" strokeWidth="2" 
      strokeLinecap="round" strokeLinejoin="round"
    >
      <circle cx="12" cy="8" r="6" />
      <path d="M15.477 12.89 17 22l-5-3-5 3 1.523-9.11" />
    </svg>
  );
}
