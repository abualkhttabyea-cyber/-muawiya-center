"use client";

import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card } from '@/components/ui/card';
import { Archive, FileDown } from 'lucide-react';
import { Button } from '@/components/ui/button';

export default function ArchivePage() {
  return (
    <DashboardShell userRole="ADMIN">
      <div className="space-y-8">
        <header>
          <h1 className="text-3xl font-black text-primary">الأرشيف العام</h1>
          <p className="text-muted-foreground mt-1">السجلات التاريخية، المستندات، والبيانات المؤرشفة</p>
        </header>

        <Card className="bg-card/20 border-2 border-dashed border-border rounded-extra py-32 flex flex-col items-center justify-center">
          <Archive className="size-24 text-muted/10 mb-6" />
          <h2 className="text-2xl font-black text-muted-foreground">الأرشيف فارغ حالياً</h2>
          <p className="text-muted-foreground/60 mt-2">لا توجد ملفات أو سجلات مؤرشفة في هذا القسم.</p>
        </Card>

        <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
          <Card className="p-8 bg-card/50 border-border rounded-2xl flex items-center justify-between group hover:border-primary/30 transition-all">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary">
                <FileDown className="size-6" />
              </div>
              <div>
                <h3 className="font-bold">سجلات الختمات</h3>
                <p className="text-xs text-muted-foreground">تحميل تقارير الطلاب الذين ختموا القرآن</p>
              </div>
            </div>
            <Button variant="ghost" className="text-primary font-bold">تصدير</Button>
          </Card>
        </div>
      </div>
    </DashboardShell>
  );
}