
"use client";

import { useSearchParams, useRouter } from 'next/navigation';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { BookOpen, Star, Loader2, Award } from 'lucide-react';
import { useState, Suspense, useMemo, useEffect } from 'react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useFirestore, useUser, useDoc } from '@/firebase';
import { collection, addDoc, doc, getDoc } from 'firebase/firestore';
import { PERFORMANCE_LABELS, QURAN_SURAHS, isStudentHafiz, getRemainingSurahs, type PerformanceLevel } from '@/lib/constants';

function MemorizationLogContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const db = useFirestore();
  const { user } = useUser();
  const studentId = searchParams.get('studentId');
  const studentName = searchParams.get('studentName');
  const { toast } = useToast();
  
  const studentRef = useMemo(() => (db && studentId) ? doc(db, 'users', studentId) : null, [db, studentId]);
  const { data: studentData } = useDoc(studentRef);

  const [loading, setLoading] = useState(false);
  const [grade, setGrade] = useState(5);
  const [performance, setPerformance] = useState<PerformanceLevel>('EXCELLENT');
  const [formData, setFormData] = useState({ surah: '', from: '', to: '', notes: '' });

  const isHafiz = useMemo(() => isStudentHafiz(studentData?.startSurah, studentData?.endSurah), [studentData]);
  const availableSurahs = useMemo(() => getRemainingSurahs(studentData?.startSurah, studentData?.endSurah), [studentData]);

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;

    setLoading(true);
    try {
      await addDoc(collection(db, 'logs'), {
        studentId,
        studentName,
        type: 'MEMORIZATION',
        surah: formData.surah,
        ayahRange: `${formData.from}-${formData.to}`,
        grade,
        performance,
        notes: formData.notes,
        date: new Date().toISOString()
      });

      toast({
        title: "تم التسجيل سحابياً",
        description: `تم حفظ سجل حفظ الطالب ${studentName} في السحابة.`,
      });
      router.back();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطأ في الاتصال",
        description: "تعذر حفظ السجل في السحابة حالياً.",
      });
    } finally {
      setLoading(false);
    }
  };

  if (isHafiz) {
    return (
      <div className="max-w-2xl mx-auto text-center space-y-8 py-12">
        <div className="w-24 h-24 bg-primary/10 rounded-full flex items-center justify-center mx-auto shadow-xl">
          <Award className="size-12 text-primary" />
        </div>
        <div className="space-y-4">
          <h1 className="text-3xl font-black text-primary">الطالب خاتم للمصحف</h1>
          <p className="text-muted-foreground text-lg leading-relaxed">
            بما أن الطالب {studentName} مسجل كخاتم للمصحف كاملاً (من الفاتحة إلى الناس)، 
            فلا يمكن تسجيل "حفظ جديد" له. يرجى التوجه لصفحة **تسجيل المراجعة** لمتابعة ضبطه.
          </p>
        </div>
        <Button onClick={() => router.back()} variant="outline" className="rounded-xl px-12 h-14 font-bold">
          العودة للخلف
        </Button>
      </div>
    );
  }

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <header className="text-center space-y-2">
        <BookOpen className="size-12 text-primary mx-auto mb-2" />
        <h1 className="text-3xl font-black text-primary">تسجيل حفظ (تسميع)</h1>
        <p className="text-muted-foreground">الطالب: {studentName}</p>
      </header>

      <Card className="bg-card/50 border-border rounded-2xl p-6 shadow-xl">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label>السورة (تظهر فقط السور التي لم يحفظها)</Label>
            <Select value={formData.surah} onValueChange={(v) => setFormData({...formData, surah: v})}>
              <SelectTrigger className="rounded-xl h-12 bg-background/50">
                <SelectValue placeholder="اختر السورة" />
              </SelectTrigger>
              <SelectContent>
                {availableSurahs.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>من الآية</Label>
              <Input 
                type="number" 
                className="rounded-xl border-border bg-background/50 h-12" 
                placeholder="1" 
                required 
                value={formData.from}
                onChange={(e) => setFormData({...formData, from: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>إلى الآية</Label>
              <Input 
                type="number" 
                className="rounded-xl border-border bg-background/50 h-12" 
                placeholder="10" 
                required 
                value={formData.to}
                onChange={(e) => setFormData({...formData, to: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>مستوى الأداء</Label>
            <Select value={performance} onValueChange={(v: PerformanceLevel) => setPerformance(v)}>
              <SelectTrigger className="rounded-xl h-12 bg-background/50">
                <SelectValue placeholder="اختر مستوى الأداء" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(PERFORMANCE_LABELS).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>التقييم الرقمي (1-5)</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setGrade(val)}
                  className={cn(
                    "flex-1 py-3 rounded-xl border transition-all flex items-center justify-center",
                    grade === val 
                      ? "bg-primary text-primary-foreground border-primary shadow-lg shadow-primary/20 scale-105" 
                      : "bg-muted border-border text-muted-foreground hover:border-primary/50"
                  )}
                >
                  <Star className={cn("size-4 ml-1", grade >= val ? "fill-current" : "")} />
                  {val}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>ملاحظات إضافية</Label>
            <Textarea 
              className="rounded-xl border-border bg-background/50 min-h-[100px]" 
              placeholder="مثال: بحاجة لضبط أحكام التجويد" 
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
            />
          </div>

          <Button 
            type="submit" 
            disabled={loading}
            className="w-full bg-primary text-primary-foreground hover:bg-primary/90 h-14 rounded-xl text-lg font-bold shadow-lg shadow-primary/20"
          >
            {loading ? <Loader2 className="animate-spin" /> : "حفظ السجل سحابياً"}
          </Button>
        </form>
      </Card>
    </div>
  );
}

export default function MemorizationLogPage() {
  const { user } = useUser();
  const db = useFirestore();
  const [role, setRole] = useState<'ADMIN' | 'TEACHER' | null>(null);

  useEffect(() => {
    if (user && db) {
      getDoc(doc(db, 'users', user.uid)).then(snap => {
        if (snap.exists()) setRole(snap.data().role);
      });
    }
  }, [user, db]);

  return (
    <DashboardShell userRole={role || 'TEACHER'}>
      <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin size-10 text-primary" /></div>}>
        <MemorizationLogContent />
      </Suspense>
    </DashboardShell>
  );
}
