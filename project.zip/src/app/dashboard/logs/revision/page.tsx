
"use client";

import { useSearchParams, useRouter } from 'next/navigation';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { History, Star, Loader2 } from 'lucide-react';
import { useState, Suspense } from 'react';
import { useToast } from '@/hooks/use-toast';
import { cn } from '@/lib/utils';
import { useFirestore, useUser } from '@/firebase';
import { collection, addDoc, doc, getDoc } from 'firebase/firestore';
import { PERFORMANCE_LABELS, QURAN_SURAHS, type PerformanceLevel } from '@/lib/constants';

function RevisionLogContent() {
  const searchParams = useSearchParams();
  const router = useRouter();
  const db = useFirestore();
  const { user } = useUser();
  const studentId = searchParams.get('studentId');
  const studentName = searchParams.get('studentName');
  const { toast } = useToast();
  
  const [loading, setLoading] = useState(false);
  const [grade, setGrade] = useState(5);
  const [performance, setPerformance] = useState<PerformanceLevel>('EXCELLENT');
  const [formData, setFormData] = useState({ surah: '', from: '', to: '', notes: '' });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!db) return;

    setLoading(true);
    try {
      await addDoc(collection(db, 'logs'), {
        studentId,
        studentName,
        type: 'REVISION',
        surah: formData.surah,
        ayahRange: `${formData.from}-${formData.to}`,
        grade,
        performance,
        notes: formData.notes,
        date: new Date().toISOString()
      });

      toast({
        title: "تم تسجيل المراجعة",
        description: `تم حفظ سجل مراجعة الطالب ${studentName} سحابياً.`,
      });
      router.back();
    } catch (error) {
      toast({
        variant: "destructive",
        title: "خطأ",
        description: "تعذر الحفظ في قاعدة البيانات السحابية.",
      });
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="max-w-2xl mx-auto space-y-6">
      <header className="text-center space-y-2">
        <History className="size-12 text-accent mx-auto mb-2" />
        <h1 className="text-3xl font-black text-accent">تسجيل مراجعة</h1>
        <p className="text-muted-foreground">الطالب: {studentName}</p>
      </header>

      <Card className="bg-card/50 border-border rounded-2xl p-6 shadow-xl border-t-4 border-t-accent/20">
        <form onSubmit={handleSubmit} className="space-y-6">
          <div className="space-y-2">
            <Label>السورة المراجعة</Label>
            <Select value={formData.surah} onValueChange={(v) => setFormData({...formData, surah: v})}>
              <SelectTrigger className="rounded-xl h-12 bg-background/50">
                <SelectValue placeholder="اختر السورة" />
              </SelectTrigger>
              <SelectContent>
                {QURAN_SURAHS.map((s) => (
                  <SelectItem key={s} value={s}>{s}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="grid grid-cols-2 gap-4">
            <div className="space-y-2">
              <Label>من الآية</Label>
              <Input 
                type="number" 
                className="rounded-xl border-border bg-background/50 h-12" 
                placeholder="1" 
                required 
                value={formData.from}
                onChange={(e) => setFormData({...formData, from: e.target.value})}
              />
            </div>
            <div className="space-y-2">
              <Label>إلى الآية</Label>
              <Input 
                type="number" 
                className="rounded-xl border-border bg-background/50 h-12" 
                placeholder="50" 
                required 
                value={formData.to}
                onChange={(e) => setFormData({...formData, to: e.target.value})}
              />
            </div>
          </div>

          <div className="space-y-2">
            <Label>مستوى تطبيق المراجعة</Label>
            <Select value={performance} onValueChange={(v: PerformanceLevel) => setPerformance(v)}>
              <SelectTrigger className="rounded-xl h-12 bg-background/50">
                <SelectValue placeholder="اختر مستوى الأداء" />
              </SelectTrigger>
              <SelectContent>
                {Object.entries(PERFORMANCE_LABELS).map(([key, label]) => (
                  <SelectItem key={key} value={key}>{label}</SelectItem>
                ))}
              </SelectContent>
            </Select>
          </div>

          <div className="space-y-2">
            <Label>جودة المراجعة (1-5)</Label>
            <div className="flex gap-2">
              {[1, 2, 3, 4, 5].map((val) => (
                <button
                  key={val}
                  type="button"
                  onClick={() => setGrade(val)}
                  className={cn(
                    "flex-1 py-3 rounded-xl border transition-all flex items-center justify-center",
                    grade === val 
                      ? "bg-accent text-accent-foreground border-accent shadow-lg shadow-accent/20 scale-105" 
                      : "bg-muted border-border text-muted-foreground hover:border-accent/50"
                  )}
                >
                  <Star className={cn("size-4 ml-1", grade >= val ? "fill-current" : "")} />
                  {val}
                </button>
              ))}
            </div>
          </div>

          <div className="space-y-2">
            <Label>ملاحظات المعلم</Label>
            <Textarea 
              className="rounded-xl border-border bg-background/50 min-h-[100px]" 
              placeholder="مثال: ضبط جيد للمخارج" 
              value={formData.notes}
              onChange={(e) => setFormData({...formData, notes: e.target.value})}
            />
          </div>

          <Button 
            type="submit" 
            disabled={loading}
            className="w-full bg-accent text-accent-foreground hover:bg-accent/90 h-14 rounded-xl text-lg font-bold shadow-lg shadow-accent/20"
          >
            {loading ? <Loader2 className="animate-spin" /> : "حفظ السجل سحابياً"}
          </Button>
        </form>
      </Card>
    </div>
  );
}

export default function RevisionLogPage() {
  const { user } = useUser();
  const db = useFirestore();
  const [role, setRole] = useState<'ADMIN' | 'TEACHER' | null>(null);

  useState(() => {
    if (user && db) {
      getDoc(doc(db, 'users', user.uid)).then(snap => {
        if (snap.exists()) setRole(snap.data().role);
      });
    }
  });

  return (
    <DashboardShell userRole={role || 'TEACHER'}>
      <Suspense fallback={<div className="flex justify-center py-20"><Loader2 className="animate-spin size-10 text-primary" /></div>}>
        <RevisionLogContent />
      </Suspense>
    </DashboardShell>
  );
}
