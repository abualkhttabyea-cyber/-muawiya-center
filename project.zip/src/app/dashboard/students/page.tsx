
"use client";

import { useState, useMemo } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UserPlus, Trash2, Users, Loader2, Phone, UserCircle, Edit2, BookOpen } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useCollection } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, where, updateDoc } from 'firebase/firestore';
import { QURAN_SURAHS } from '@/lib/constants';

export default function StudentsPage() {
  const { toast } = useToast();
  const db = useFirestore();
  
  const studentsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'users'), where('role', '==', 'STUDENT'), where('approved', '==', true));
  }, [db]);
  const { data: students, loading } = useCollection(studentsQuery);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingStudent, setEditingStudent] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [newUser, setNewUser] = useState({ name: '', phone: '', startSurah: '', endSurah: '' });

  const handleAddStudent = async () => {
    if (!newUser.name || !db) return;
    setSaving(true);
    try {
      await addDoc(collection(db, 'users'), {
        ...newUser,
        role: 'STUDENT',
        approved: true,
        roleAr: 'طالب',
        createdAt: new Date().toISOString()
      });
      setIsAddOpen(false);
      setNewUser({ name: '', phone: '', startSurah: '', endSurah: '' });
      toast({ title: "تمت إضافة الطالب", description: "تم تسجيل الطالب ومقدار حفظه في السحابة بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل إضافة الطالب للسحابة." });
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateStudent = async () => {
    if (!editingStudent || !db) return;
    setSaving(true);
    try {
      const userRef = doc(db, 'users', editingStudent.id);
      await updateDoc(userRef, {
        name: editingStudent.name,
        phone: editingStudent.phone,
        startSurah: editingStudent.startSurah,
        endSurah: editingStudent.endSurah
      });
      setIsEditOpen(false);
      toast({ title: "تم التحديث", description: "تم تعديل بيانات الطالب سحابياً بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل تحديث بيانات الطالب." });
    } finally {
      setSaving(false);
    }
  };

  const handleDelete = async (id: string) => {
    if (!db) return;
    if (confirm("هل أنت متأكد من حذف هذا الطالب نهائياً؟")) {
      await deleteDoc(doc(db, 'users', id));
      toast({ title: "تم الحذف", description: "تمت إزالة سجل الطالب من السحابة." });
    }
  };

  return (
    <DashboardShell userRole="ADMIN">
      <div className="space-y-8">
        <header className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-black text-primary">شؤون الطلاب</h1>
            <p className="text-muted-foreground mt-1">إدارة بيانات الطلاب ومقدار الحفظ سحابياً</p>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-xl bg-accent text-accent-foreground shadow-lg">
                <UserPlus className="size-4 ml-2" />
                إضافة طالب يدوياً
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border rounded-3xl">
              <DialogHeader><DialogTitle className="text-primary font-black text-right">تسجيل طالب جديد</DialogTitle></DialogHeader>
              <div className="space-y-4 py-4 text-right" dir="rtl">
                <div className="space-y-2">
                  <Label>اسم الطالب الكامل</Label>
                  <Input value={newUser.name} onChange={(e) => setNewUser({...newUser, name: e.target.value})} className="rounded-xl" placeholder="مثال: أحمد محمد علي" />
                </div>
                <div className="space-y-2">
                  <Label>رقم الجوال (للتواصل)</Label>
                  <Input value={newUser.phone} onChange={(e) => setNewUser({...newUser, phone: e.target.value})} className="rounded-xl text-left" dir="ltr" placeholder="05xxxxxxxx" />
                </div>
                <div className="grid grid-cols-2 gap-4">
                  <div className="space-y-2">
                    <Label>حافظ من سورة</Label>
                    <Select value={newUser.startSurah} onValueChange={(v) => setNewUser({...newUser, startSurah: v})}>
                      <SelectTrigger className="rounded-xl"><SelectValue placeholder="اختر السورة" /></SelectTrigger>
                      <SelectContent>
                        {QURAN_SURAHS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                  <div className="space-y-2">
                    <Label>إلى سورة</Label>
                    <Select value={newUser.endSurah} onValueChange={(v) => setNewUser({...newUser, endSurah: v})}>
                      <SelectTrigger className="rounded-xl"><SelectValue placeholder="اختر السورة" /></SelectTrigger>
                      <SelectContent>
                        {QURAN_SURAHS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                      </SelectContent>
                    </Select>
                  </div>
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAddStudent} disabled={saving} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">
                  {saving ? <Loader2 className="animate-spin" /> : "حفظ الطالب سحابياً"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        <div className="grid grid-cols-1 gap-4">
          {loading ? (
            <div className="text-center py-20 text-muted-foreground"><Loader2 className="animate-spin mx-auto mb-2" /> جاري تحميل قائمة الطلاب...</div>
          ) : students?.length === 0 ? (
            <Card className="bg-card/20 border-2 border-dashed border-border rounded-[2.5rem] py-20 flex flex-col items-center justify-center">
              <Users className="size-16 text-muted/20 mb-4" />
              <h2 className="text-xl font-bold text-muted-foreground">لا يوجد طلاب مسجلين حالياً</h2>
            </Card>
          ) : (
            students?.map((student: any) => (
              <Card key={student.id} className="bg-card/50 border-border rounded-2xl overflow-hidden hover:border-primary/30 transition-all">
                <CardContent className="p-4 flex items-center justify-between">
                  <div className="flex items-center gap-4">
                    <div className="w-12 h-12 bg-muted rounded-xl flex items-center justify-center">
                      <UserCircle className="size-6 text-accent" />
                    </div>
                    <div className="text-right">
                      <h3 className="font-bold text-lg">{student.name}</h3>
                      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground mt-1">
                        <span className="flex items-center gap-1 font-mono" dir="ltr"><Phone className="size-3" /> {student.phone || 'بدون جوال'}</span>
                        {(student.startSurah || student.endSurah) && (
                          <span className="flex items-center gap-1"><BookOpen className="size-3" /> من {student.startSurah || '؟'} إلى {student.endSurah || '؟'}</span>
                        )}
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => { setEditingStudent(student); setIsEditOpen(true); }} 
                      variant="ghost" 
                      className="text-primary hover:bg-primary/10 rounded-xl"
                    >
                      <Edit2 className="size-5" />
                    </Button>
                    <Button 
                      onClick={() => handleDelete(student.id)} 
                      variant="ghost" 
                      className="text-destructive hover:bg-destructive/10 rounded-xl"
                    >
                      <Trash2 className="size-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent className="bg-card border-border rounded-3xl">
            <DialogHeader><DialogTitle className="text-primary font-black text-right">تعديل بيانات الطالب</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4 text-right" dir="rtl">
              <div className="space-y-2">
                <Label>اسم الطالب الكامل</Label>
                <Input value={editingStudent?.name || ''} onChange={(e) => setEditingStudent({...editingStudent, name: e.target.value})} className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>رقم الجوال</Label>
                <Input value={editingStudent?.phone || ''} onChange={(e) => setEditingStudent({...editingStudent, phone: e.target.value})} className="rounded-xl text-left" dir="ltr" />
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div className="space-y-2">
                  <Label>حافظ من سورة</Label>
                  <Select value={editingStudent?.startSurah || ''} onValueChange={(v) => setEditingStudent({...editingStudent, startSurah: v})}>
                    <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {QURAN_SURAHS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>إلى سورة</Label>
                  <Select value={editingStudent?.endSurah || ''} onValueChange={(v) => setEditingStudent({...editingStudent, endSurah: v})}>
                    <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      {QURAN_SURAHS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                    </SelectContent>
                  </Select>
                </div>
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleUpdateStudent} disabled={saving} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">
                {saving ? <Loader2 className="animate-spin" /> : "حفظ التغييرات"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardShell>
  );
}
