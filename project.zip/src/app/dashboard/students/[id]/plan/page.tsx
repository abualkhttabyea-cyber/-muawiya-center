
"use client";

import { useState, useMemo, useEffect } from 'react';
import { useParams, useRouter } from 'next/navigation';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { Calendar, Save, ListChecks, ArrowRight, Loader2, RefreshCw, AlertCircle } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useDoc } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { PERFORMANCE_LABELS, QURAN_SURAHS, isStudentHafiz, getRemainingSurahs, type PerformanceLevel } from '@/lib/constants';

export default function StudentPlanPage() {
  const { id: studentId } = useParams();
  const router = useRouter();
  const { toast } = useToast();
  const db = useFirestore();

  const studentRef = useMemo(() => db ? doc(db, 'users', studentId as string) : null, [db, studentId]);
  const { data: student } = useDoc(studentRef);

  const planRef = useMemo(() => db ? doc(db, 'plans', studentId as string) : null, [db, studentId]);
  const { data: plan, loading: planLoading } = useDoc(planRef);

  const [cycleType, setCycleType] = useState<'WEEKLY' | 'MONTHLY'>('WEEKLY');
  const [tasks, setTasks] = useState<any[]>([]);
  const [saving, setSaving] = useState(false);

  const isHafiz = useMemo(() => isStudentHafiz(student?.startSurah, student?.endSurah), [student]);

  useEffect(() => {
    if (plan) {
      setCycleType(plan.cycleType || 'WEEKLY');
      setTasks(plan.tasks || []);
    } else {
      const defaultTasks = Array.from({ length: 7 }, (_, i) => ({
        dayNumber: i + 1,
        hifzTask: '',
        revisionTask: ''
      }));
      setTasks(defaultTasks);
    }
  }, [plan]);

  const handleCycleChange = (val: 'WEEKLY' | 'MONTHLY') => {
    setCycleType(val);
    const length = val === 'WEEKLY' ? 7 : 30;
    const newTasks = Array.from({ length }, (_, i) => ({
      dayNumber: i + 1,
      hifzTask: '',
      revisionTask: ''
    }));
    setTasks(newTasks);
  };

  const updateTask = (day: number, field: 'hifzTask' | 'revisionTask', val: string) => {
    setTasks(prev => prev.map(t => t.dayNumber === day ? { ...t, [field]: val } : t));
  };

  const handleSave = async () => {
    if (!db || !planRef) return;
    setSaving(true);
    try {
      await setDoc(planRef, {
        studentId,
        cycleType,
        tasks,
        updatedAt: new Date().toISOString()
      }, { merge: true });
      toast({ title: "تم حفظ الخطة", description: "تم تحديث خطة الحفظ والمراجعة الدورية للطالب." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل حفظ الخطة سحابياً." });
    } finally {
      setSaving(false);
    }
  };

  return (
    <DashboardShell userRole="TEACHER">
      <div className="space-y-8 pb-20">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div className="flex items-center gap-4">
            <Button variant="ghost" onClick={() => router.back()} className="rounded-xl">
              <ArrowRight className="size-5" />
            </Button>
            <div>
              <h1 className="text-3xl font-black text-primary">خطة الطالب: {student?.name || '...'}</h1>
              <p className="text-muted-foreground">بناء وتعديل مسار الحفظ والمراجعة الدوري</p>
            </div>
          </div>
          <Button onClick={handleSave} disabled={saving} className="bg-primary text-primary-foreground rounded-2xl px-8 h-12 shadow-lg shadow-primary/20">
            {saving ? <Loader2 className="animate-spin ml-2" /> : <Save className="size-5 ml-2" />}
            حفظ الخطة السحابية
          </Button>
        </header>

        {isHafiz && (
          <div className="bg-blue-500/10 border border-blue-500/20 p-6 rounded-3xl flex items-start gap-4 text-right" dir="rtl">
            <AlertCircle className="size-6 text-blue-500 shrink-0 mt-1" />
            <div>
              <h3 className="font-bold text-blue-500 text-lg">تنبيه: الطالب خاتم للمصحف</h3>
              <p className="text-sm text-blue-500/80 leading-relaxed">
                هذا الطالب مسجل كخاتم للمصحف كاملاً. يرجى التركيز في الخطة على مهام **المراجعة والضبط** فقط. 
                سيتم تجاهل حقول "الحفظ" في التقارير التلقائية.
              </p>
            </div>
          </div>
        )}

        <Card className="bg-card/50 border-border rounded-3xl overflow-hidden">
          <CardHeader className="bg-muted/30 border-b border-border">
            <div className="flex flex-col md:flex-row md:items-center justify-between gap-4">
              <CardTitle className="text-lg font-bold flex items-center gap-2">
                <Calendar className="size-5 text-primary" />
                إعدادات الدورة الزمنية
              </CardTitle>
              <div className="flex items-center gap-2">
                <Label className="text-sm font-bold ml-2">نوع الخطة:</Label>
                <Select value={cycleType} onValueChange={handleCycleChange}>
                  <SelectTrigger className="w-[180px] rounded-xl">
                    <SelectValue />
                  </SelectTrigger>
                  <SelectContent>
                    <SelectItem value="WEEKLY">أسبوعية (7 أيام)</SelectItem>
                    <SelectItem value="MONTHLY">شهرية (30 يوم)</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
          </CardHeader>
          <CardContent className="p-6">
            <div className="grid grid-cols-1 gap-4">
              {tasks.map((task) => (
                <div key={task.dayNumber} className="flex flex-col md:flex-row items-start md:items-center gap-4 p-4 bg-muted/20 rounded-2xl border border-border/50 group hover:border-primary/30 transition-all">
                  <div className="w-12 h-12 rounded-xl bg-primary/10 flex items-center justify-center font-black text-primary shrink-0">
                    {task.dayNumber}
                  </div>
                  <div className="grid grid-cols-1 md:grid-cols-2 gap-4 flex-1 w-full">
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground mr-1">الحفظ (سور/آيات) {isHafiz && "(معطل للخاتم)"}</Label>
                      <Input 
                        disabled={isHafiz}
                        placeholder={isHafiz ? "الطالب خاتم..." : "أدخل مهمة الحفظ..."}
                        value={task.hifzTask}
                        onChange={(e) => updateTask(task.dayNumber, 'hifzTask', e.target.value)}
                        className="rounded-xl border-border bg-background/50 h-10 text-sm disabled:opacity-30"
                      />
                    </div>
                    <div className="space-y-1">
                      <Label className="text-[10px] text-muted-foreground mr-1">المراجعة (أجزاء/سور)</Label>
                      <Input 
                        placeholder="أدخل مهمة المراجعة..."
                        value={task.revisionTask}
                        onChange={(e) => updateTask(task.dayNumber, 'revisionTask', e.target.value)}
                        className="rounded-xl border-border bg-background/50 h-10 text-sm"
                      />
                    </div>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
