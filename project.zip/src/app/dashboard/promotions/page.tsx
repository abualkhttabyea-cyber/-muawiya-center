
"use client";

import { useMemo, useState } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { Award, UserCheck, ShieldCheck, TrendingUp, Loader2 } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useCollection } from '@/firebase';
import { collection, query, where, updateDoc, doc } from 'firebase/firestore';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { ROLE_LABELS } from '@/lib/constants';

export default function PromotionsPage() {
  const { toast } = useToast();
  const db = useFirestore();
  
  // جلب كافة الكوادر التعليمية الذين تمت الموافقة عليهم
  const staffQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'users'), where('role', 'in', ['TEACHER', 'MANAGER', 'DEPUTY_MANAGER', 'SUPERVISOR']));
  }, [db]);
  const { data: staff, loading } = useCollection(staffQuery);

  const [updating, setUpdating] = useState<string | null>(null);

  const handlePromote = async (userId: string, newRole: string) => {
    if (!db) return;
    setUpdating(userId);
    try {
      const userRef = doc(db, 'users', userId);
      await updateDoc(userRef, { 
        role: newRole,
        roleAr: ROLE_LABELS[newRole]
      });
      toast({ title: "تم تحديث المنصب", description: "تم منح الصلاحيات الجديدة للمستخدم سحابياً بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل تحديث المنصب في السحابة." });
    } finally {
      setUpdating(null);
    }
  };

  return (
    <DashboardShell>
      <div className="space-y-8">
        <header>
          <div className="flex items-center gap-3 text-primary mb-2">
            <Award className="size-8" />
            <h1 className="text-3xl font-black">نظام إدارة الترقيات والصلاحيات</h1>
          </div>
          <p className="text-muted-foreground mt-1">منح صلاحيات إدارية عليا للمعلمين وتوزيع الأدوار القيادية في المركز</p>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
          <Card className="bg-primary/5 border-primary/20 rounded-2xl p-6 border-r-4 border-r-primary">
            <ShieldCheck className="size-8 text-primary mb-2" />
            <h3 className="font-bold">مدير المركز</h3>
            <p className="text-xs text-muted-foreground">صلاحيات كاملة للمتابعة والمالية والاعتمادات والتقارير.</p>
          </Card>
          <Card className="bg-blue-500/5 border-blue-500/20 rounded-2xl p-6 border-r-4 border-r-blue-500">
            <UserCheck className="size-8 text-blue-500 mb-2" />
            <h3 className="font-bold">نائب المدير</h3>
            <p className="text-xs text-muted-foreground">مساعدة المدير في إدارة الحلقات وشؤون المعلمين اليومية.</p>
          </Card>
          <Card className="bg-green-500/5 border-green-500/20 rounded-2xl p-6 border-r-4 border-r-green-500">
            <TrendingUp className="size-8 text-green-500 mb-2" />
            <h3 className="font-bold">مشرف الحلقات</h3>
            <p className="text-xs text-muted-foreground">متابعة دقيقة لخطط الطلاب، حلقات التحفيظ، وسجلات الإنجاز.</p>
          </Card>
        </div>

        <Card className="bg-card/50 border-border rounded-2xl overflow-hidden shadow-xl">
          <CardHeader className="bg-muted/20 border-b border-border/50">
            <CardTitle className="text-lg font-bold">قائمة الكادر القابل للترقية</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-20 text-center"><Loader2 className="animate-spin mx-auto text-primary" /></div>
            ) : staff?.length === 0 ? (
              <div className="p-20 text-center text-muted-foreground">لا يوجد كادر تعليمي مسجل حالياً.</div>
            ) : (
              <div className="divide-y divide-border/50">
                {staff?.map((member: any) => (
                  <div key={member.id} className="p-6 flex flex-col md:flex-row items-center justify-between gap-6 hover:bg-muted/10 transition-colors">
                    <div className="flex items-center gap-4">
                      <div className="w-14 h-14 bg-muted rounded-2xl flex items-center justify-center font-bold text-primary border border-primary/10">
                        {member.name?.charAt(0) || '؟'}
                      </div>
                      <div>
                        <h3 className="font-bold text-lg">{member.name}</h3>
                        <p className="text-xs text-muted-foreground" dir="ltr">{member.email}</p>
                        <Badge variant="outline" className="mt-2 text-primary border-primary/20">
                          المنصب الحالي: {ROLE_LABELS[member.role] || member.roleAr}
                        </Badge>
                      </div>
                    </div>

                    <div className="flex items-center gap-4 w-full md:w-auto">
                      <div className="flex-1 md:w-56">
                        <Select 
                          value={member.role} 
                          onValueChange={(v) => handlePromote(member.id, v)}
                          disabled={updating === member.id}
                        >
                          <SelectTrigger className="rounded-xl bg-background/50 h-12">
                            <SelectValue placeholder="اختر المنصب الجديد" />
                          </SelectTrigger>
                          <SelectContent>
                            <SelectItem value="TEACHER">معلم (عادي)</SelectItem>
                            <SelectItem value="SUPERVISOR">مشرف حلقات</SelectItem>
                            <SelectItem value="DEPUTY_MANAGER">نائب مدير</SelectItem>
                            <SelectItem value="MANAGER">مدير مركز</SelectItem>
                          </SelectContent>
                        </Select>
                      </div>
                      {updating === member.id && <Loader2 className="animate-spin text-primary" />}
                    </div>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
