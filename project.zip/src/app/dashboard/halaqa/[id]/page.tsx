
"use client";

import { useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, History, ClipboardCheck, Sparkles, UserCircle, UserPlus, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import Link from 'next/link';
import { useFirestore, useDoc, useCollection } from '@/firebase';
import { doc, collection, query, where, addDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export default function HalaqaDetailsPage() {
  const params = useParams();
  const db = useFirestore();
  const { toast } = useToast();
  
  const ringRef = useMemo(() => db ? doc(db, 'halaqat', params.id as string) : null, [db, params.id]);
  const { data: ring } = useDoc(ringRef);

  const studentsQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'users'), where('role', '==', 'STUDENT'), where('approved', '==', true), where('halaqaId', '==', params.id));
  }, [db, params.id]);
  const { data: students } = useCollection(studentsQuery);

  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [newStudent, setNewStudent] = useState({ name: '', phone: '', startSurah: '', endSurah: '' });
  const [adding, setAdding] = useState(false);

  const handleAddStudent = async () => {
    if (!newStudent.name || !db) return;
    setAdding(true);
    try {
      await addDoc(collection(db, 'users'), {
        ...newStudent,
        role: 'STUDENT',
        approved: true,
        halaqaId: params.id,
        createdAt: new Date().toISOString()
      });
      setIsAddStudentOpen(false);
      setNewStudent({ name: '', phone: '', startSurah: '', endSurah: '' });
      toast({ title: "تم إضافة الطالب", description: "تم تسجيل الطالب في الحلقة ومقدار حفظه سحابياً." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل إضافة الطالب." });
    } finally {
      setAdding(false);
    }
  };

  return (
    <DashboardShell userRole="TEACHER">
      <div className="space-y-6">
        <header className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-primary mb-1">
              <Badge variant="outline">المعلم: {ring?.teacher || '...'}</Badge>
              <Badge variant="outline">المستوى: {ring?.levelAr || '...'}</Badge>
            </div>
            <h1 className="text-3xl font-black text-primary">{ring?.name || 'تفاصيل الحلقة'}</h1>
          </div>
          <div className="flex gap-2">
            <Dialog open={isAddStudentOpen} onOpenChange={setIsAddStudentOpen}>
              <DialogTrigger asChild>
                <Button className="rounded-xl bg-accent text-accent-foreground"><UserPlus className="size-4 ml-2" />إضافة طالب للحلقة</Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border rounded-3xl">
                <DialogHeader><DialogTitle className="text-primary font-black">تسجيل طالب ومقدار الحفظ</DialogTitle></DialogHeader>
                <div className="space-y-4 py-4 text-right" dir="rtl">
                  <div className="space-y-2"><Label>اسم الطالب</Label><Input value={newStudent.name} onChange={(e) => setNewStudent({...newStudent, name: e.target.value})} className="rounded-xl" /></div>
                  <div className="space-y-2"><Label>الجوال</Label><Input value={newStudent.phone} onChange={(e) => setNewStudent({...newStudent, phone: e.target.value})} className="rounded-xl text-left" dir="ltr" /></div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2"><Label>من سورة</Label><Input value={newStudent.startSurah} onChange={(e) => setNewStudent({...newStudent, startSurah: e.target.value})} className="rounded-xl" /></div>
                    <div className="space-y-2"><Label>إلى سورة</Label><Input value={newStudent.endSurah} onChange={(e) => setNewStudent({...newStudent, endSurah: e.target.value})} className="rounded-xl" /></div>
                  </div>
                </div>
                <DialogFooter><Button onClick={handleAddStudent} disabled={adding} className="w-full rounded-xl">{adding ? <Loader2 className="animate-spin" /> : "حفظ الطالب"}</Button></DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-4">
          {students?.map((student: any) => (
            <Card key={student.id} className="bg-card/40 border-border hover:border-primary/20 transition-all">
              <CardContent className="p-6 flex flex-col md:flex-row md:items-center justify-between gap-6">
                <div className="flex items-center gap-4">
                  <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center font-bold text-primary"><UserCircle className="size-6" /></div>
                  <div>
                    <h3 className="text-lg font-bold">{student.name}</h3>
                    <p className="text-xs text-muted-foreground">حافظ من {student.startSurah || '؟'} إلى {student.endSurah || '؟'}</p>
                  </div>
                </div>
                <div className="flex flex-wrap gap-2">
                  <Button asChild className="bg-primary text-primary-foreground rounded-xl">
                    <Link href={`/dashboard/logs/memorization?studentId=${student.id}&studentName=${encodeURIComponent(student.name)}`}><BookOpen className="size-4 ml-2" />تسجيل حفظ</Link>
                  </Button>
                  <Button asChild className="bg-accent text-accent-foreground rounded-xl">
                    <Link href={`/dashboard/logs/revision?studentId=${student.id}&studentName=${encodeURIComponent(student.name)}`}><History className="size-4 ml-2" />تسجيل مراجعة</Link>
                  </Button>
                  <Button asChild variant="outline" className="border-primary/20 text-primary rounded-xl">
                    <Link href={`/dashboard/insights/${student.id}`}><Sparkles className="size-4 ml-2" />تحليل AI</Link>
                  </Button>
                </div>
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    </DashboardShell>
  );
}
