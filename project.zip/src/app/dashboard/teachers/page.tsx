
"use client";

import { useState, useMemo } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { UserPlus, Trash2, Mail, GraduationCap, Loader2, Phone, Edit2, KeyRound, Share2 } from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Label } from '@/components/ui/label';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useCollection, useAuth } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, where, updateDoc } from 'firebase/firestore';
import { sendPasswordResetEmail } from 'firebase/auth';

export default function TeachersPage() {
  const { toast } = useToast();
  const db = useFirestore();
  const auth = useAuth();
  
  const teachersQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'users'), where('role', '==', 'TEACHER'), where('approved', '==', true));
  }, [db]);
  const { data: teachers, loading } = useCollection(teachersQuery);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingTeacher, setEditingTeacher] = useState<any>(null);
  const [saving, setSaving] = useState(false);
  const [processingId, setProcessingId] = useState<string | null>(null);
  const [newUser, setNewUser] = useState({ name: '', email: '', phone: '' });

  const handleAddTeacher = async () => {
    if (!newUser.name || !db) return;
    setSaving(true);
    try {
      await addDoc(collection(db, 'users'), {
        ...newUser,
        role: 'TEACHER',
        approved: true,
        roleAr: 'معلم',
        createdAt: new Date().toISOString()
      });
      setIsAddOpen(false);
      setNewUser({ name: '', email: '', phone: '' });
      toast({ title: "تم إضافة المعلم", description: "تم تفعيل حساب المعلم الجديد في السحابة بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل إضافة المعلم للسحابة." });
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateTeacher = async () => {
    if (!editingTeacher || !db) return;
    setSaving(true);
    try {
      const userRef = doc(db, 'users', editingTeacher.id);
      await updateDoc(userRef, {
        name: editingTeacher.name,
        email: editingTeacher.email,
        phone: editingTeacher.phone
      });
      setIsEditOpen(false);
      toast({ title: "تم التحديث", description: "تم تعديل بيانات المعلم سحابياً بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل تحديث بيانات المعلم." });
    } finally {
      setSaving(false);
    }
  };

  const handleShareToTeacher = (teacher: any) => {
    const url = window.location.origin;
    const text = `السلام عليكم ورحمة الله وبركاته.. أستاذ ${teacher.name}، تم تفعيل حسابك في المنصة السحابية لمركز معاوية. يمكنك الدخول الآن عبر الرابط: ${url}`;
    window.open(`https://wa.me/${teacher.phone}?text=${encodeURIComponent(text)}`, '_blank');
  };

  const handleResetPassword = async (email: string, id: string) => {
    if (!auth) return;
    setProcessingId(id);
    try {
      await sendPasswordResetEmail(auth, email);
      toast({ title: "تم إرسال الرابط", description: `تم إرسال رابط إعادة تعيين كلمة المرور إلى ${email}` });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل الإرسال", description: "تأكد من صحة البريد أو صلاحيات النظام." });
    } finally {
      setProcessingId(null);
    }
  };

  const handleDelete = async (id: string) => {
    if (!db) return;
    if (confirm("هل أنت متأكد من حذف هذا المعلم؟ سيتم إلغاء تعيينه من كافة الحلقات.")) {
      await deleteDoc(doc(db, 'users', id));
      toast({ title: "تم الحذف", description: "تمت إزالة سجل المعلم من السحابة." });
    }
  };

  return (
    <DashboardShell userRole="ADMIN">
      <div className="space-y-8">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-black text-primary">شؤون المعلمين</h1>
            <p className="text-muted-foreground mt-1">إدارة طاقم التدريس المعتمد والبيانات الوظيفية</p>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-xl bg-accent text-accent-foreground shadow-lg">
                <UserPlus className="size-4 ml-2" />
                إضافة معلم يدوياً
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border rounded-3xl">
              <DialogHeader><DialogTitle className="text-primary font-black text-right">إضافة معلم جديد</DialogTitle></DialogHeader>
              <div className="space-y-4 py-4 text-right" dir="rtl">
                <div className="space-y-2">
                  <Label>اسم المعلم الكامل</Label>
                  <Input value={newUser.name} onChange={(e) => setNewUser({...newUser, name: e.target.value})} className="rounded-xl" placeholder="مثال: د. عبدالله علي" />
                </div>
                <div className="space-y-2">
                  <Label>البريد الإلكتروني</Label>
                  <Input value={newUser.email} onChange={(e) => setNewUser({...newUser, email: e.target.value})} className="rounded-xl text-left" dir="ltr" placeholder="example@muawiya.edu" />
                </div>
                <div className="space-y-2">
                  <Label>رقم الجوال</Label>
                  <Input value={newUser.phone} onChange={(e) => setNewUser({...newUser, phone: e.target.value})} className="rounded-xl text-left" dir="ltr" placeholder="05xxxxxxxx" />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAddTeacher} disabled={saving} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">
                  {saving ? <Loader2 className="animate-spin" /> : "حفظ المعلم سحابياً"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        <div className="grid grid-cols-1 gap-4">
          {loading ? (
            <div className="text-center py-20 text-muted-foreground"><Loader2 className="animate-spin mx-auto mb-2" /> جاري التحميل...</div>
          ) : (
            teachers?.map((teacher: any) => (
              <Card key={teacher.id} className="bg-card/50 border-border rounded-2xl overflow-hidden hover:border-primary/30 transition-all">
                <CardContent className="p-4 flex flex-col md:flex-row items-center justify-between gap-4">
                  <div className="flex items-center gap-4 flex-1">
                    <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center">
                      <GraduationCap className="size-6 text-primary" />
                    </div>
                    <div className="text-right">
                      <h3 className="font-bold text-lg">{teacher.name}</h3>
                      <div className="flex flex-wrap gap-4 text-xs text-muted-foreground mt-1">
                        <span className="flex items-center gap-1 font-mono" dir="ltr"><Mail className="size-3" /> {teacher.email || 'لا يوجد بريد'}</span>
                        <span className="flex items-center gap-1 font-mono" dir="ltr"><Phone className="size-3" /> {teacher.phone || 'بدون جوال'}</span>
                      </div>
                    </div>
                  </div>
                  <div className="flex gap-2">
                    <Button 
                      onClick={() => handleShareToTeacher(teacher)}
                      variant="ghost" 
                      title="إرسال رابط المنصة للمعلم"
                      className="text-green-500 hover:bg-green-500/10 rounded-xl"
                    >
                      <Share2 className="size-5" />
                    </Button>
                    <Button 
                      onClick={() => handleResetPassword(teacher.email, teacher.id)} 
                      disabled={processingId === teacher.id}
                      variant="ghost" 
                      title="إرسال رابط إعادة تعيين كلمة المرور"
                      className="text-accent hover:bg-accent/10 rounded-xl"
                    >
                      {processingId === teacher.id ? <Loader2 className="animate-spin size-5" /> : <KeyRound className="size-5" />}
                    </Button>
                    <Button 
                      onClick={() => { setEditingTeacher(teacher); setIsEditOpen(true); }} 
                      variant="ghost" 
                      className="text-primary hover:bg-primary/10 rounded-xl"
                    >
                      <Edit2 className="size-5" />
                    </Button>
                    <Button 
                      onClick={() => handleDelete(teacher.id)} 
                      variant="ghost" 
                      className="text-destructive hover:bg-destructive/10 rounded-xl"
                    >
                      <Trash2 className="size-5" />
                    </Button>
                  </div>
                </CardContent>
              </Card>
            ))
          )}
        </div>

        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent className="bg-card border-border rounded-3xl">
            <DialogHeader><DialogTitle className="text-primary font-black text-right">تعديل بيانات المعلم</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4 text-right" dir="rtl">
              <div className="space-y-2">
                <Label>الاسم الكامل</Label>
                <Input value={editingTeacher?.name || ''} onChange={(e) => setEditingTeacher({...editingTeacher, name: e.target.value})} className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>البريد الإلكتروني</Label>
                <Input value={editingTeacher?.email || ''} onChange={(e) => setEditingTeacher({...editingTeacher, email: e.target.value})} className="rounded-xl text-left" dir="ltr" />
              </div>
              <div className="space-y-2">
                <Label>رقم الجوال</Label>
                <Input value={editingTeacher?.phone || ''} onChange={(e) => setEditingTeacher({...editingTeacher, phone: e.target.value})} className="rounded-xl text-left" dir="ltr" />
              </div>
            </div>
            <DialogFooter>
              <Button onClick={handleUpdateTeacher} disabled={saving} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">
                {saving ? <Loader2 className="animate-spin" /> : "حفظ التغييرات"}
              </Button>
            </DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardShell>
  );
}
