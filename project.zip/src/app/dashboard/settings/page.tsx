
"use client";

import { useState, useEffect, useMemo } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Settings, Save, Image as ImageIcon, ShieldAlert, Loader2, Info, Lock, LifeBuoy } from 'lucide-react';
import { useToast } from '@/hooks/use-toast';
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { useFirestore, useDoc, useAuth, useUser } from '@/firebase';
import { doc, setDoc } from 'firebase/firestore';
import { updatePassword, updateEmail, reauthenticateWithCredential, EmailAuthProvider } from 'firebase/auth';

export default function CenterSettingsPage() {
  const { toast } = useToast();
  const db = useFirestore();
  const auth = useAuth();
  const { user } = useUser();
  const logoData = PlaceHolderImages.find(img => img.id === 'center-logo');
  const defaultLogo = logoData?.imageUrl || "https://picsum.photos/seed/muawiya-official-logo/800/800";

  const settingsRef = useMemo(() => db ? doc(db, 'settings', 'center') : null, [db]);
  const { data: remoteSettings } = useDoc(settingsRef);

  const [centerName, setCenterName] = useState('');
  const [centerLogo, setCenterLogo] = useState(defaultLogo);
  const [newAdminEmail, setNewAdminEmail] = useState('');
  const [recoveryEmail, setRecoveryEmail] = useState('');
  const [recoveryPhone, setRecoveryPhone] = useState('');
  
  const [newPassword, setNewPassword] = useState('');
  const [currentPassword, setCurrentPassword] = useState('');
  const [savingIdentity, setSavingIdentity] = useState(false);
  const [savingAccount, setSavingAccount] = useState(false);

  useEffect(() => {
    if (remoteSettings) {
      setCenterName(remoteSettings.name || 'مركز معاويه لتحفيظ القران الكريم وعلومه');
      setCenterLogo(remoteSettings.logoUrl || defaultLogo);
      setNewAdminEmail(remoteSettings.adminEmail || user?.email || '');
      setRecoveryEmail(remoteSettings.recoveryEmail || '');
      setRecoveryPhone(remoteSettings.recoveryPhone || '');
    } else if (user) {
      setNewAdminEmail(user.email || '');
    }
  }, [remoteSettings, defaultLogo, user]);

  const handleSaveIdentity = async () => {
    if (!db || !settingsRef) return;
    setSavingIdentity(true);
    try {
      await setDoc(settingsRef, {
        name: centerName,
        logoUrl: centerLogo,
        adminEmail: newAdminEmail,
        recoveryEmail: recoveryEmail,
        recoveryPhone: recoveryPhone,
        updatedAt: new Date().toISOString()
      }, { merge: true });
      toast({ title: "تم تحديث الهوية", description: "تم حفظ الشعار والاسم الجديد سحابياً بنجاح." });
    } catch (error) {
      toast({ variant: "destructive", title: "خطأ", description: "تأكد من صلاحيات الوصول." });
    } finally {
      setSavingIdentity(false);
    }
  };

  const handleUpdateAccount = async () => {
    if (!user || !auth || !currentPassword) {
      toast({ variant: "destructive", title: "تنبيه", description: "يرجى إدخال كلمة المرور الحالية لتأكيد الهوية." });
      return;
    }
    
    setSavingAccount(true);
    try {
      const credential = EmailAuthProvider.credential(user.email!, currentPassword);
      await reauthenticateWithCredential(user, credential);

      if (newAdminEmail && newAdminEmail !== user.email) {
        await updateEmail(user, newAdminEmail);
      }
      if (newPassword) {
        await updatePassword(user, newPassword);
      }
      
      toast({ title: "تم التحديث بنجاح", description: "تم تحديث بيانات الوصول السحابية فوراً." });
      setNewPassword('');
      setCurrentPassword('');
    } catch (error: any) {
      console.error(error);
      let msg = "حدث خطأ أثناء التحديث.";
      if (error.code === 'auth/wrong-password') msg = "كلمة المرور الحالية غير صحيحة.";
      toast({ variant: "destructive", title: "فشل التحديث", description: msg });
    } finally {
      setSavingAccount(false);
    }
  };

  const handleLogoChange = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (file) {
      const reader = new FileReader();
      reader.onloadend = () => setCenterLogo(reader.result as string);
      reader.readAsDataURL(file);
    }
  };

  return (
    <DashboardShell userRole="ADMIN">
      <div className="max-w-4xl mx-auto space-y-10 pb-20 text-right">
        <header className="space-y-2">
          <div className="flex items-center gap-3 text-primary mb-2 justify-end">
            <h1 className="text-4xl font-black">إعدادات الإدارة</h1>
            <Settings className="size-8" />
          </div>
        </header>

        <Card className="bg-card/30 backdrop-blur-xl border-primary/20 rounded-[2.5rem] overflow-hidden">
          <CardHeader className="p-8 border-b border-border/30 bg-primary/5">
            <CardTitle className="flex items-center gap-3 text-primary font-black justify-end">
              هوية المركز والشعار
              <ImageIcon className="size-6" />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8 space-y-8">
            <div className="flex flex-col md:flex-row-reverse gap-10 items-center">
              <div className="relative group">
                <div className="w-48 h-48 flex items-center justify-center bg-muted/20 rounded-3xl overflow-hidden border-2 border-dashed border-primary/20">
                  <Image src={centerLogo} alt="Logo" width={192} height={192} className="w-full h-full object-contain p-4" priority />
                </div>
                <Label htmlFor="logo-upload" className="absolute -bottom-3 -right-3 bg-primary text-primary-foreground p-4 rounded-2xl cursor-pointer shadow-xl transition-all active:scale-95 z-10">
                  <ImageIcon className="size-6" />
                  <input id="logo-upload" type="file" className="hidden" accept="image/*" onChange={handleLogoChange} />
                </Label>
              </div>

              <div className="flex-1 w-full space-y-6">
                <div className="space-y-3">
                  <Label className="text-lg font-bold text-primary">اسم المركز الرسمي</Label>
                  <input 
                    value={centerName} 
                    onChange={(e) => setCenterName(e.target.value)} 
                    className="w-full rounded-2xl h-14 bg-background/50 text-right font-bold border border-border/50 px-4 outline-none focus:border-primary" 
                  />
                </div>
                <Button onClick={handleSaveIdentity} disabled={savingIdentity} className="w-full bg-primary text-primary-foreground h-14 rounded-2xl font-black shadow-lg shadow-primary/20">
                  {savingIdentity ? <Loader2 className="animate-spin ml-2" /> : <Save className="size-5 ml-2" />}
                  تحديث الهوية السحابية
                </Button>
              </div>
            </div>
          </CardContent>
        </Card>

        <Card className="bg-card/30 border-blue-500/20 rounded-[2.5rem] overflow-hidden">
          <CardHeader className="p-8 border-b border-border/30 bg-blue-500/5">
            <CardTitle className="flex items-center gap-3 text-blue-500 font-black justify-end">
              بيانات استعادة الوصول للمشرف
              <LifeBuoy className="size-6" />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
             <div className="bg-blue-500/10 p-4 rounded-xl flex items-start gap-3 border border-blue-500/20 text-right" dir="rtl">
              <Info className="size-5 text-blue-500 mt-0.5 shrink-0" />
              <p className="text-xs text-blue-500 font-bold leading-relaxed">في حال نسيت كلمة مرور المشرف، سيقوم النظام بعرض خيارات التواصل هذه لمساعدتك في استعادة حسابك يدوياً.</p>
            </div>
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              <div className="space-y-2">
                <Label className="font-bold">بريد الاستعادة البديل</Label>
                <input 
                  value={recoveryEmail} 
                  onChange={(e) => setRecoveryEmail(e.target.value)} 
                  placeholder="example@gmail.com" 
                  className="w-full rounded-xl h-12 bg-background/50 border border-border/50 px-4 text-left outline-none" 
                  dir="ltr" 
                />
              </div>
              <div className="space-y-2">
                <Label className="font-bold">جوال الاستعادة (واتساب)</Label>
                <input 
                  value={recoveryPhone} 
                  onChange={(e) => setRecoveryPhone(e.target.value)} 
                  placeholder="05xxxxxxxx" 
                  className="w-full rounded-xl h-12 bg-background/50 border border-border/50 px-4 text-left outline-none" 
                  dir="ltr" 
                />
              </div>
            </div>
            <Button onClick={handleSaveIdentity} disabled={savingIdentity} variant="outline" className="w-full border-blue-500 text-blue-500 hover:bg-blue-500 hover:text-white h-12 rounded-xl font-bold">
              {savingIdentity ? <Loader2 className="animate-spin ml-2" /> : "حفظ بيانات الاستعادة السحابية"}
            </Button>
          </CardContent>
        </Card>

        <Card className="bg-card/30 border-accent/20 rounded-[2.5rem] overflow-hidden">
          <CardHeader className="p-8 border-b border-border/30 bg-accent/5">
            <CardTitle className="flex items-center gap-3 text-accent font-black justify-end">
              تغيير بيانات الدخول الحالية
              <ShieldAlert className="size-6" />
            </CardTitle>
          </CardHeader>
          <CardContent className="p-8 space-y-6">
            <div className="bg-accent/10 p-4 rounded-xl flex items-start gap-3 border border-accent/20 text-right" dir="rtl">
              <Info className="size-5 text-accent mt-0.5 shrink-0" />
              <p className="text-xs text-accent font-bold leading-relaxed">لتغيير البريد أو كلمة المرور، يجب إدخال كلمة المرور الحالية لتأكيد الهوية وتجنب الخروج من النظام.</p>
            </div>
            
            <div className="space-y-4">
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                <div className="space-y-2">
                  <Label className="font-bold">بريد الإدارة الجديد</Label>
                  <input 
                    value={newAdminEmail} 
                    onChange={(e) => setNewAdminEmail(e.target.value)} 
                    className="w-full rounded-xl h-12 bg-background/50 border border-border/50 px-4 text-left outline-none" 
                    dir="ltr" 
                  />
                </div>
                <div className="space-y-2">
                  <Label className="font-bold">كلمة مرور جديدة</Label>
                  <input 
                    type="password" 
                    value={newPassword} 
                    onChange={(e) => setNewPassword(e.target.value)} 
                    placeholder="اتركه فارغاً للحفاظ على الحالية" 
                    className="w-full rounded-xl h-12 bg-background/50 border border-border/50 px-4 outline-none" 
                  />
                </div>
              </div>
              
              <div className="pt-4 border-t border-border/30">
                <div className="max-w-sm mx-auto space-y-3">
                  <Label className="font-black text-destructive flex items-center gap-2 justify-center">
                    <Lock className="size-4" />
                    تأكيد بكلمة المرور الحالية
                  </Label>
                  <input 
                    type="password" 
                    value={currentPassword} 
                    onChange={(e) => setCurrentPassword(e.target.value)} 
                    placeholder="أدخل كلمتك الحالية لتنفيذ التغيير" 
                    className="w-full rounded-xl h-14 bg-background/50 border border-destructive/30 focus:border-destructive text-center outline-none" 
                  />
                  <Button onClick={handleUpdateAccount} disabled={savingAccount || !currentPassword} variant="outline" className="w-full border-accent text-accent hover:bg-accent hover:text-accent-foreground h-14 rounded-2xl font-black">
                    {savingAccount ? <Loader2 className="animate-spin ml-2" /> : "تحديث بيانات الحساب فوراً"}
                  </Button>
                </div>
              </div>
            </div>
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
