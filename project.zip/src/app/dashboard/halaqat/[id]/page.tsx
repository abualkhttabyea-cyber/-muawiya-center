
"use client";

import { useMemo, useState } from 'react';
import { useParams } from 'next/navigation';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { BookOpen, History, Sparkles, UserCircle, UserPlus, Loader2, CalendarRange } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import Link from 'next/link';
import { useFirestore, useDoc, useCollection, useUser } from '@/firebase';
import { doc, collection, query, where, addDoc, getDoc } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';
import { QURAN_SURAHS } from '@/lib/constants';

export default function HalaqaDetailsPage() {
  const params = useParams();
  const db = useFirestore();
  const { user } = useUser();
  const { toast } = useToast();
  
  const ringRef = useMemo(() => db ? doc(db, 'halaqat', params.id as string) : null, [db, params.id]);
  const { data: ring } = useDoc(ringRef);

  const studentsQuery = useMemo(() => {
    if (!db) return null;
    return query(
      collection(db, 'users'), 
      where('role', '==', 'STUDENT'), 
      where('approved', '==', true),
      where('halaqaId', '==', params.id)
    );
  }, [db, params.id]);
  const { data: students } = useCollection(studentsQuery);

  const [isAddStudentOpen, setIsAddStudentOpen] = useState(false);
  const [newStudent, setNewStudent] = useState({ name: '', phone: '', startSurah: '', endSurah: '' });
  const [adding, setAdding] = useState(false);
  const [role, setRole] = useState<'ADMIN' | 'TEACHER' | null>(null);

  useState(() => {
    if (user && db) {
      getDoc(doc(db, 'users', user.uid)).then(snap => {
        if (snap.exists()) setRole(snap.data().role);
      });
    }
  });

  const handleAddStudent = async () => {
    if (!newStudent.name || !db) return;
    setAdding(true);
    try {
      await addDoc(collection(db, 'users'), {
        ...newStudent,
        role: 'STUDENT',
        approved: true,
        roleAr: 'طالب',
        halaqaId: params.id,
        createdAt: new Date().toISOString()
      });
      setIsAddStudentOpen(false);
      setNewStudent({ name: '', phone: '', startSurah: '', endSurah: '' });
      toast({ title: "تم إضافة الطالب", description: "تم تسجيل الطالب الجديد في هذه الحلقة سحابياً." });
    } catch (e) {
      toast({ variant: "destructive", title: "خطأ", description: "فشل إضافة الطالب للسحابة." });
    } finally {
      setAdding(false);
    }
  };

  return (
    <DashboardShell userRole={role || 'TEACHER'}>
      <div className="space-y-6">
        <header className="flex flex-col md:flex-row justify-between gap-4">
          <div>
            <div className="flex items-center gap-2 text-primary mb-1">
              <Badge variant="outline" className="border-primary/30 text-primary">المعلم: {ring?.teacher || '...'}</Badge>
              <Badge variant="outline" className="border-primary/30 text-primary">المستوى: {ring?.levelAr || '...'}</Badge>
            </div>
            <h1 className="text-3xl font-black text-primary">{ring?.name || 'تفاصيل الحلقة'}</h1>
            <p className="text-muted-foreground">متابعة طلاب الحلقة وتعديل خطط الحفظ سحابياً</p>
          </div>
          <div className="flex gap-2">
            <Dialog open={isAddStudentOpen} onOpenChange={setIsAddStudentOpen}>
              <DialogTrigger asChild>
                <Button className="rounded-xl bg-accent text-accent-foreground">
                  <UserPlus className="size-4 ml-2" />
                  إضافة طالب للحلقة
                </Button>
              </DialogTrigger>
              <DialogContent className="bg-card border-border rounded-3xl">
                <DialogHeader>
                  <DialogTitle className="text-primary font-black text-right">تسجيل طالب في هذه الحلقة</DialogTitle>
                </DialogHeader>
                <div className="space-y-4 py-4 text-right" dir="rtl">
                  <div className="space-y-2">
                    <Label>اسم الطالب</Label>
                    <Input 
                      value={newStudent.name}
                      onChange={(e) => setNewStudent({...newStudent, name: e.target.value})}
                      placeholder="الاسم الكامل"
                      className="rounded-xl"
                    />
                  </div>
                  <div className="space-y-2">
                    <Label>رقم الجوال</Label>
                    <Input 
                      value={newStudent.phone}
                      onChange={(e) => setNewStudent({...newStudent, phone: e.target.value})}
                      placeholder="05xxxxxxxx"
                      className="rounded-xl text-left"
                      dir="ltr"
                    />
                  </div>
                  <div className="grid grid-cols-2 gap-4">
                    <div className="space-y-2">
                      <Label>حافظ من سورة</Label>
                      <Select value={newStudent.startSurah} onValueChange={(v) => setNewStudent({...newStudent, startSurah: v})}>
                        <SelectTrigger className="rounded-xl"><SelectValue placeholder="اختر" /></SelectTrigger>
                        <SelectContent>
                          {QURAN_SURAHS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                    <div className="space-y-2">
                      <Label>إلى سورة</Label>
                      <Select value={newStudent.endSurah} onValueChange={(v) => setNewStudent({...newStudent, endSurah: v})}>
                        <SelectTrigger className="rounded-xl"><SelectValue placeholder="اختر" /></SelectTrigger>
                        <SelectContent>
                          {QURAN_SURAHS.map(s => <SelectItem key={s} value={s}>{s}</SelectItem>)}
                        </SelectContent>
                      </Select>
                    </div>
                  </div>
                </div>
                <DialogFooter>
                  <Button onClick={handleAddStudent} disabled={adding} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">
                    {adding ? <Loader2 className="animate-spin" /> : "حفظ الطالب في الحلقة"}
                  </Button>
                </DialogFooter>
              </DialogContent>
            </Dialog>
          </div>
        </header>

        <div className="grid grid-cols-1 gap-4">
          {(students?.length || 0) > 0 ? (
            students?.map((student: any) => (
              <Card key={student.id} className="bg-card/40 border-border hover:border-primary/20 transition-all overflow-hidden">
                <CardContent className="p-0">
                  <div className="flex flex-col md:flex-row md:items-center justify-between p-6 gap-6">
                    <div className="flex items-center gap-4">
                      <div className="w-12 h-12 rounded-xl bg-muted flex items-center justify-center font-bold text-primary">
                        <UserCircle className="size-6" />
                      </div>
                      <div>
                        <h3 className="text-lg font-bold">{student.name}</h3>
                        <p className="text-xs text-muted-foreground">
                          {student.startSurah && student.endSurah 
                            ? `حافظ من ${student.startSurah} إلى ${student.endSurah}` 
                            : 'لم يتم تحديد مقدار الحفظ'}
                        </p>
                      </div>
                    </div>

                    <div className="flex flex-wrap gap-2">
                      <Button asChild className="bg-primary text-primary-foreground hover:bg-primary/90 rounded-xl">
                        <Link href={`/dashboard/logs/memorization?studentId=${student.id}&studentName=${encodeURIComponent(student.name)}`}>
                          <BookOpen className="size-4 ml-2" />
                          تسجيل حفظ
                        </Link>
                      </Button>
                      <Button asChild className="bg-accent text-accent-foreground hover:bg-accent/90 rounded-xl">
                        <Link href={`/dashboard/logs/revision?studentId=${student.id}&studentName=${encodeURIComponent(student.name)}`}>
                          <History className="size-4 ml-2" />
                          تسجيل مراجعة
                        </Link>
                      </Button>
                      <Button asChild variant="outline" className="border-green-500/50 text-green-500 hover:bg-green-500/10 rounded-xl">
                        <Link href={`/dashboard/students/${student.id}/plan`}>
                          <CalendarRange className="size-4 ml-2" />
                          الخطة الدراسية
                        </Link>
                      </Button>
                      <Button asChild variant="outline" className="border-primary/20 text-primary hover:bg-primary/10 rounded-xl">
                        <Link href={`/dashboard/insights/${student.id}`}>
                          <Sparkles className="size-4 ml-2" />
                          تحليل AI
                        </Link>
                      </Button>
                    </div>
                  </div>
                </CardContent>
              </Card>
            ))
          ) : (
            <div className="text-center py-20 bg-card/10 rounded-3xl border border-dashed border-border">
              <p className="text-muted-foreground">لا يوجد طلاب مسجلين في هذه الحلقة حالياً.</p>
            </div>
          )}
        </div>
      </div>
    </DashboardShell>
  );
}
