
"use client";

import { useState, useMemo } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { Badge } from '@/components/ui/badge';
import { GraduationCap, Plus, ArrowRight, Trash2, UserCog, Edit2, Loader2 } from 'lucide-react';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { useToast } from '@/hooks/use-toast';
import { useFirestore, useCollection } from '@/firebase';
import { collection, addDoc, deleteDoc, doc, query, where, updateDoc } from 'firebase/firestore';
import Link from 'next/link';

export default function HalaqatPage() {
  const { toast } = useToast();
  const db = useFirestore();
  
  const halaqatRef = useMemo(() => db ? collection(db, 'halaqat') : null, [db]);
  const { data: rings, loading } = useCollection(halaqatRef);

  const teachersQuery = useMemo(() => {
    if (!db) return null;
    return query(collection(db, 'users'), where('role', '==', 'TEACHER'), where('approved', '==', true));
  }, [db]);
  const { data: teachers } = useCollection(teachersQuery);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [isEditOpen, setIsEditOpen] = useState(false);
  const [editingRing, setEditingRing] = useState<any>(null);
  const [newRing, setNewRing] = useState({ name: '', teacherId: '', level: 'BEGINNER' });
  const [saving, setSaving] = useState(false);

  const levelsAr: Record<string, string> = {
    BEGINNER: 'مبتدئ',
    INTERMEDIATE: 'متوسط',
    ADVANCED: 'متقدم'
  };

  const handleAddRing = async () => {
    if (!newRing.name || !newRing.teacherId || !halaqatRef) {
      toast({ variant: "destructive", title: "خطأ", description: "يرجى تعبئة كافة الحقول واختيار المعلم" });
      return;
    }

    setSaving(true);
    try {
      const selectedTeacher = teachers?.find(t => t.id === newRing.teacherId);
      await addDoc(halaqatRef, {
        ...newRing,
        teacher: selectedTeacher?.name || 'غير معروف',
        levelAr: levelsAr[newRing.level],
        createdAt: new Date().toISOString()
      });
      setIsAddOpen(false);
      setNewRing({ name: '', teacherId: '', level: 'BEGINNER' });
      toast({ title: "تمت إضافة الحلقة", description: "تم إنشاء الحلقة وتعيين المعلم بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل الإضافة", description: "حدث خطأ أثناء الاتصال بالسحابة." });
    } finally {
      setSaving(false);
    }
  };

  const handleUpdateRing = async () => {
    if (!editingRing || !db) return;
    setSaving(true);
    try {
      const selectedTeacher = teachers?.find(t => t.id === editingRing.teacherId);
      const ringRef = doc(db, 'halaqat', editingRing.id);
      await updateDoc(ringRef, {
        name: editingRing.name,
        teacherId: editingRing.teacherId,
        teacher: selectedTeacher?.name || editingRing.teacher,
        level: editingRing.level,
        levelAr: levelsAr[editingRing.level]
      });
      setIsEditOpen(false);
      toast({ title: "تم التحديث", description: "تم تعديل بيانات الحلقة سحابياً بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل التحديث", description: "تعذر حفظ التغييرات في السحابة." });
    } finally {
      setSaving(false);
    }
  };

  const handleDeleteRing = async (id: string) => {
    if (!db) return;
    if (confirm("هل أنت متأكد من حذف هذه الحلقة؟ سيتم إلغاء تعيين الطلاب منها.")) {
      await deleteDoc(doc(db, 'halaqat', id));
      toast({ title: "تم الحذف", description: "تمت إزالة الحلقة من السحابة بنجاح." });
    }
  };

  return (
    <DashboardShell userRole="ADMIN">
      <div className="space-y-8">
        <div className="flex justify-between items-center">
          <div>
            <h1 className="text-3xl font-black text-primary">إدارة الحلقات والتعيينات</h1>
            <p className="text-muted-foreground mt-1">تنظيم المجموعات التعليمية وتوزيع المعلمين المعتمدين</p>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="rounded-xl bg-accent text-accent-foreground shadow-lg">
                <Plus className="size-4 ml-2" />
                إنشاء حلقة جديدة
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border rounded-3xl">
              <DialogHeader><DialogTitle className="text-primary font-black text-right">إضافة حلقة وتعيين معلم</DialogTitle></DialogHeader>
              <div className="space-y-4 py-4 text-right" dir="rtl">
                <div className="space-y-2">
                  <Label>اسم الحلقة</Label>
                  <Input value={newRing.name} onChange={(e) => setNewRing({...newRing, name: e.target.value})} placeholder="مثال: حلقة الإتقان" className="rounded-xl" />
                </div>
                <div className="space-y-2">
                  <Label>المعلم المسؤول</Label>
                  <Select value={newRing.teacherId} onValueChange={(v) => setNewRing({...newRing, teacherId: v})}>
                    <SelectTrigger className="rounded-xl"><SelectValue placeholder="اختر معلماً معتمداً" /></SelectTrigger>
                    <SelectContent>
                      {teachers?.map((teacher: any) => (<SelectItem key={teacher.id} value={teacher.id}>{teacher.name}</SelectItem>))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>المستوى التعليمي</Label>
                  <Select value={newRing.level} onValueChange={(v) => setNewRing({...newRing, level: v})}>
                    <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                    <SelectContent>
                      <SelectItem value="BEGINNER">مبتدئ</SelectItem>
                      <SelectItem value="INTERMEDIATE">متوسط</SelectItem>
                      <SelectItem value="ADVANCED">متقدم</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
              </div>
              <DialogFooter><Button onClick={handleAddRing} disabled={saving} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">{saving ? <Loader2 className="animate-spin" /> : "حفظ الحلقة"}</Button></DialogFooter>
            </DialogContent>
          </Dialog>
        </div>

        {loading ? (
          <div className="text-center py-20 text-muted-foreground"><Loader2 className="animate-spin mx-auto mb-2" /> جاري تحميل الحلقات...</div>
        ) : (
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-6">
            {rings?.map((ring: any) => (
              <Card key={ring.id} className="bg-card/50 border-border rounded-2xl border-t-4 border-t-primary/20 hover:border-primary/40 transition-all overflow-hidden">
                <CardHeader className="flex flex-row items-center justify-between pb-2">
                  <div className="w-12 h-12 bg-primary/10 rounded-xl flex items-center justify-center text-primary"><GraduationCap className="size-6" /></div>
                  <Badge className="bg-primary/10 text-primary border-none text-[10px]">{ring.levelAr}</Badge>
                </CardHeader>
                <CardContent className="pt-4 space-y-4 text-right">
                  <CardTitle className="text-xl font-bold">{ring.name}</CardTitle>
                  <div className="flex items-center justify-between text-sm">
                    <span className="text-muted-foreground">المعلم:</span>
                    <span className="font-semibold flex items-center gap-1"><UserCog className="size-3 text-primary" />{ring.teacher}</span>
                  </div>
                  <div className="flex gap-2 pt-2">
                    <Button asChild className="flex-1 rounded-xl bg-muted text-foreground hover:bg-primary hover:text-primary-foreground">
                      <Link href={`/dashboard/halaqat/${ring.id}`}>المتابعة <ArrowRight className="size-4 mr-2" /></Link>
                    </Button>
                    <Button onClick={() => { setEditingRing(ring); setIsEditOpen(true); }} variant="outline" size="icon" className="rounded-xl"><Edit2 className="size-4" /></Button>
                    <Button onClick={() => handleDeleteRing(ring.id)} variant="outline" size="icon" className="rounded-xl text-destructive hover:bg-destructive/10"><Trash2 className="size-4" /></Button>
                  </div>
                </CardContent>
              </Card>
            ))}
          </div>
        )}

        <Dialog open={isEditOpen} onOpenChange={setIsEditOpen}>
          <DialogContent className="bg-card border-border rounded-3xl">
            <DialogHeader><DialogTitle className="text-primary font-black text-right">تعديل بيانات الحلقة</DialogTitle></DialogHeader>
            <div className="space-y-4 py-4 text-right" dir="rtl">
              <div className="space-y-2">
                <Label>اسم الحلقة</Label>
                <Input value={editingRing?.name || ''} onChange={(e) => setEditingRing({...editingRing, name: e.target.value})} className="rounded-xl" />
              </div>
              <div className="space-y-2">
                <Label>المعلم المسؤول</Label>
                <Select value={editingRing?.teacherId || ''} onValueChange={(v) => setEditingRing({...editingRing, teacherId: v})}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {teachers?.map((teacher: any) => (<SelectItem key={teacher.id} value={teacher.id}>{teacher.name}</SelectItem>))}
                  </SelectContent>
                </Select>
              </div>
              <div className="space-y-2">
                <Label>المستوى التعليمي</Label>
                <Select value={editingRing?.level || 'BEGINNER'} onValueChange={(v) => setEditingRing({...editingRing, level: v})}>
                  <SelectTrigger className="rounded-xl"><SelectValue /></SelectTrigger>
                  <SelectContent>
                    <SelectItem value="BEGINNER">مبتدئ</SelectItem>
                    <SelectItem value="INTERMEDIATE">متوسط</SelectItem>
                    <SelectItem value="ADVANCED">متقدم</SelectItem>
                  </SelectContent>
                </Select>
              </div>
            </div>
            <DialogFooter><Button onClick={handleUpdateRing} disabled={saving} className="w-full rounded-xl bg-primary text-primary-foreground font-bold">{saving ? <Loader2 className="animate-spin" /> : "حفظ التغييرات"}</Button></DialogFooter>
          </DialogContent>
        </Dialog>
      </div>
    </DashboardShell>
  );
}
