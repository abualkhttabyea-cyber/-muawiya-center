
"use client";

import { useMemo, useState } from 'react';
import { DashboardShell } from '@/components/layout/DashboardShell';
import { Card, CardContent, CardHeader, CardTitle } from '@/components/ui/card';
import { Button } from '@/components/ui/button';
import { 
  Wallet, 
  TrendingUp, 
  TrendingDown, 
  ArrowUpRight,
  ArrowDownRight,
  Plus,
  Loader2
} from 'lucide-react';
import { 
  Table, 
  TableBody, 
  TableCell, 
  TableHead, 
  TableHeader, 
  TableRow 
} from '@/components/ui/table';
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from '@/components/ui/dialog';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from '@/components/ui/select';
import { cn } from '@/lib/utils';
import { useFirestore, useCollection } from '@/firebase';
import { collection, addDoc, query, orderBy, limit } from 'firebase/firestore';
import { useToast } from '@/hooks/use-toast';

export default function FinancePage() {
  const { toast } = useToast();
  const db = useFirestore();
  const financeRef = useMemo(() => db ? collection(db, 'finance') : null, [db]);
  const financeQuery = useMemo(() => financeRef ? query(financeRef, orderBy('date', 'desc'), limit(20)) : null, [financeRef]);
  const { data: records, loading } = useCollection(financeQuery);

  const [isAddOpen, setIsAddOpen] = useState(false);
  const [newRecord, setNewRecord] = useState({ type: 'INCOME', category: '', amount: '', description: '' });
  const [adding, setAdding] = useState(false);

  const handleAdd = async () => {
    if (!newRecord.category || !newRecord.amount || !db) return;
    
    setAdding(true);
    try {
      await addDoc(collection(db, 'finance'), {
        ...newRecord,
        amount: Number(newRecord.amount),
        date: new Date().toISOString().split('T')[0]
      });
      setIsAddOpen(false);
      setNewRecord({ type: 'INCOME', category: '', amount: '', description: '' });
      toast({ title: "تم تسجيل المعاملة", description: "تمت إضافة السجل المالي للسحابة بنجاح." });
    } catch (e) {
      toast({ variant: "destructive", title: "فشل الحفظ", description: "حدث خطأ أثناء الاتصال بالسحابة." });
    } finally {
      setAdding(false);
    }
  };

  const totals = useMemo(() => {
    if (!records) return { income: 0, expense: 0, net: 0 };
    const income = records.filter((r: any) => r.type === 'INCOME').reduce((acc, r: any) => acc + r.amount, 0);
    const expense = records.filter((r: any) => r.type === 'EXPENSE').reduce((acc, r: any) => acc + r.amount, 0);
    return { income, expense, net: income - expense };
  }, [records]);

  return (
    <DashboardShell userRole="ADMIN">
      <div className="space-y-8">
        <header className="flex flex-col md:flex-row justify-between items-start md:items-center gap-4">
          <div>
            <h1 className="text-3xl font-black text-primary">السجلات المالية السحابية</h1>
            <p className="text-muted-foreground mt-1">تتبع التدفق النقدي المباشر للمركز</p>
          </div>
          
          <Dialog open={isAddOpen} onOpenChange={setIsAddOpen}>
            <DialogTrigger asChild>
              <Button className="bg-accent text-accent-foreground rounded-xl shadow-lg">
                <Plus className="size-4 ml-2" />
                إضافة معاملة سحابية
              </Button>
            </DialogTrigger>
            <DialogContent className="bg-card border-border rounded-3xl">
              <DialogHeader>
                <DialogTitle className="text-primary font-black">إضافة سجل مالي</DialogTitle>
              </DialogHeader>
              <div className="space-y-4 py-4">
                <div className="space-y-2">
                  <Label>النوع</Label>
                  <Select value={newRecord.type} onValueChange={(v) => setNewRecord({...newRecord, type: v})}>
                    <SelectTrigger className="rounded-xl bg-background/50">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="INCOME">إيراد / تبرع</SelectItem>
                      <SelectItem value="EXPENSE">مصروف / رواتب</SelectItem>
                    </SelectContent>
                  </Select>
                </div>
                <div className="space-y-2">
                  <Label>الفئة</Label>
                  <Input 
                    value={newRecord.category}
                    onChange={(e) => setNewRecord({...newRecord, category: e.target.value})}
                    placeholder="مثال: اشتراكات، صيانة"
                    className="rounded-xl bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>المبلغ (ر.س)</Label>
                  <Input 
                    type="number"
                    value={newRecord.amount}
                    onChange={(e) => setNewRecord({...newRecord, amount: e.target.value})}
                    placeholder="0.00"
                    className="rounded-xl bg-background/50"
                  />
                </div>
                <div className="space-y-2">
                  <Label>الوصف</Label>
                  <Input 
                    value={newRecord.description}
                    onChange={(e) => setNewRecord({...newRecord, description: e.target.value})}
                    placeholder="تفاصيل إضافية"
                    className="rounded-xl bg-background/50"
                  />
                </div>
              </div>
              <DialogFooter>
                <Button onClick={handleAdd} disabled={adding} className="w-full bg-primary text-primary-foreground rounded-xl font-bold">
                  {adding ? <Loader2 className="animate-spin" /> : "حفظ في السحابة"}
                </Button>
              </DialogFooter>
            </DialogContent>
          </Dialog>
        </header>

        <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
          <Card className="bg-card/50 border-border rounded-2xl overflow-hidden border-t-4 border-t-green-500/20">
            <CardHeader className="pb-2">
              <TrendingUp className="size-6 text-green-500 mb-2" />
              <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي الإيرادات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-foreground">{totals.income} ر.س</div>
            </CardContent>
          </Card>
          <Card className="bg-card/50 border-border rounded-2xl overflow-hidden border-t-4 border-t-red-500/20">
            <CardHeader className="pb-2">
              <TrendingDown className="size-6 text-red-500 mb-2" />
              <CardTitle className="text-sm font-medium text-muted-foreground">إجمالي المصروفات</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-foreground">{totals.expense} ر.س</div>
            </CardContent>
          </Card>
          <Card className={cn(
            "bg-card/50 border-border rounded-2xl overflow-hidden border-t-4",
            totals.net >= 0 ? "border-t-primary/20" : "border-t-destructive/20"
          )}>
            <CardHeader className="pb-2">
              <Wallet className="size-6 text-primary mb-2" />
              <CardTitle className="text-sm font-medium text-muted-foreground">صافي الرصيد</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="text-3xl font-black text-foreground">{totals.net} ر.س</div>
            </CardContent>
          </Card>
        </div>

        <Card className="bg-card/50 border-border rounded-2xl overflow-hidden shadow-xl">
          <CardHeader className="border-b border-border/50 bg-muted/20">
            <CardTitle className="text-lg font-bold">آخر المعاملات السحابية</CardTitle>
          </CardHeader>
          <CardContent className="p-0">
            {loading ? (
              <div className="p-10 text-center"><Loader2 className="animate-spin mx-auto text-primary" /></div>
            ) : records?.length === 0 ? (
              <div className="p-20 text-center text-muted-foreground">لا توجد سجلات مالية حالياً.</div>
            ) : (
              <Table>
                <TableHeader>
                  <TableRow className="hover:bg-transparent bg-muted/10">
                    <TableHead className="text-right">التاريخ</TableHead>
                    <TableHead className="text-right">الفئة</TableHead>
                    <TableHead className="text-right">الوصف</TableHead>
                    <TableHead className="text-center">النوع</TableHead>
                    <TableHead className="text-left">المبلغ</TableHead>
                  </TableRow>
                </TableHeader>
                <TableBody>
                  {records?.map((record: any) => (
                    <TableRow key={record.id} className="hover:bg-muted/30">
                      <TableCell className="font-medium">{record.date}</TableCell>
                      <TableCell className="font-bold">{record.category}</TableCell>
                      <TableCell className="text-muted-foreground text-xs">{record.description}</TableCell>
                      <TableCell className="text-center">
                        {record.type === 'INCOME' ? (
                          <div className="inline-flex items-center gap-1 bg-green-500/10 text-green-500 px-3 py-1 rounded-full text-[10px] font-bold">
                            <ArrowUpRight className="size-3" />
                            إيراد
                          </div>
                        ) : (
                          <div className="inline-flex items-center gap-1 bg-red-500/10 text-red-500 px-3 py-1 rounded-full text-[10px] font-bold">
                            <ArrowDownRight className="size-3" />
                            مصروف
                          </div>
                        )}
                      </TableCell>
                      <TableCell className={cn(
                        "font-black text-left",
                        record.type === 'INCOME' ? "text-green-500" : "text-red-500"
                      )}>
                        {record.type === 'INCOME' ? '+' : '-'}{record.amount} ر.س
                      </TableCell>
                    </TableRow>
                  ))}
                </TableBody>
              </Table>
            )}
          </CardContent>
        </Card>
      </div>
    </DashboardShell>
  );
}
