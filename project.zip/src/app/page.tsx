
"use client";

import { useState, useEffect, useMemo } from 'react';
import { useRouter } from 'next/navigation';
import { Eye, EyeOff, Loader2, AlertCircle, ShieldAlert } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import { Alert, AlertDescription } from "@/components/ui/alert";
import Image from 'next/image';
import { PlaceHolderImages } from '@/lib/placeholder-images';
import { useAuth, useUser, useFirestore, useDoc } from '@/firebase';
import { signInWithEmailAndPassword, createUserWithEmailAndPassword, signOut } from 'firebase/auth';
import { doc, setDoc, getDoc } from 'firebase/firestore';
import Link from 'next/link';

export default function RootLoginPage() {
  const router = useRouter();
  const { toast } = useToast();
  
  const auth = useAuth();
  const db = useFirestore();
  const { user, loading: authLoading } = useUser();
  
  const [loading, setLoading] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showSetup, setShowSetup] = useState(false);
  const [errorMsg, setErrorMsg] = useState<string | null>(null);
  
  const [email, setEmail] = useState('');
  const [password, setPassword] = useState('');

  const settingsRef = useMemo(() => db ? doc(db, 'settings', 'center') : null, [db]);
  const { data: centerSettings } = useDoc(settingsRef);

  const logoData = PlaceHolderImages.find(img => img.id === 'center-logo');
  const OFFICIAL_NAME = centerSettings?.name || 'مركز معاويه لتحفيظ القران الكريم وعلومه';
  const centerLogo = centerSettings?.logoUrl || logoData?.imageUrl;

  useEffect(() => {
    if (user && !authLoading && db) {
      getDoc(doc(db, 'users', user.uid)).then(snap => {
        if (snap.exists() && snap.data().approved) {
          router.replace('/dashboard');
        } else if (snap.exists() && !snap.data().approved) {
          setErrorMsg("بانتظار موافقة الإدارة على الحساب.");
          signOut(auth!);
        }
      });
    }
  }, [user, authLoading, db, router, auth]);

  const handleCreateAdminProfile = async (uid: string, userEmail: string) => {
    if (!db) return;
    await setDoc(doc(db, 'users', uid), {
      name: 'المشرف العام',
      email: userEmail,
      role: 'ADMIN',
      approved: true,
      roleAr: 'مشرف عام',
      createdAt: new Date().toISOString()
    });
  };

  const handleForceAdmin = async () => {
    if (!auth || !db || !email || !password) {
      setErrorMsg("يرجى إدخال البريد وكلمة المرور أولاً للتهيئة.");
      return;
    }
    setLoading(true);
    try {
      try {
        const userCredential = await createUserWithEmailAndPassword(auth, email, password);
        await handleCreateAdminProfile(userCredential.user.uid, email);
      } catch (e: any) {
        if (e.code === 'auth/email-already-in-use') {
          const userCredential = await signInWithEmailAndPassword(auth, email, password);
          await handleCreateAdminProfile(userCredential.user.uid, email);
        } else {
          throw e;
        }
      }
      
      toast({ title: "تمت التهيئة بنجاح", description: "تم منحك صلاحيات المشرف العام فوراً." });
      router.push('/dashboard');
    } catch (e: any) {
      setErrorMsg("حدث خطأ أثناء التهيئة: " + e.message);
    } finally {
      setLoading(false);
    }
  };

  const performLogin = async (e?: React.FormEvent) => {
    if (e) e.preventDefault();
    setLoading(true);
    setErrorMsg(null);

    if (!auth || !db) {
      setErrorMsg("النظام السحابي غير متصل حالياً.");
      setLoading(false);
      return;
    }

    try {
      const userCredential = await signInWithEmailAndPassword(auth, email, password);
      const userDoc = await getDoc(doc(db, 'users', userCredential.user.uid));
      
      if (!userDoc.exists() || !userDoc.data().approved) {
        setErrorMsg("بانتظار موافقة الإدارة على الحساب.");
        await signOut(auth);
      } else {
        router.push('/dashboard');
      }
    } catch (error: any) {
      console.error(error);
      setErrorMsg("البيانات غير صحيحة. هل أنت المشرف؟");
      setShowSetup(true);
    } finally {
      setLoading(false);
    }
  };

  if (authLoading) return <div className="min-h-screen bg-background flex items-center justify-center"><Loader2 className="animate-spin text-primary size-10" /></div>;

  return (
    <div className="min-h-screen bg-background flex flex-col items-center justify-center p-6 relative overflow-hidden font-body text-right">
      <div className="watermark-bg opacity-5 scale-125" style={{ backgroundImage: centerLogo ? `url(${centerLogo})` : 'none' }} />
      <div className="z-10 w-full max-w-lg flex flex-col items-center fade-slide-in">
        <div className="relative w-32 h-32 mb-6">
          <Image src={centerLogo || "https://picsum.photos/seed/muawiya-logo/512/512"} alt="Logo" fill className="object-contain" priority />
        </div>
        <h1 className="text-2xl font-black text-primary mb-6 text-center">{OFFICIAL_NAME}</h1>
        <div className="w-full bg-card/40 backdrop-blur-3xl border border-primary/20 p-8 rounded-extra shadow-2xl">
          <form onSubmit={performLogin} className="space-y-6">
            {errorMsg && (
              <Alert className="rounded-xl border-destructive/20 bg-destructive/5">
                <AlertCircle className="size-4 text-destructive" />
                <AlertDescription className="mr-2 font-bold text-destructive">{errorMsg}</AlertDescription>
              </Alert>
            )}
            <div className="space-y-2 text-right">
              <label className="text-xs font-bold text-muted-foreground mr-1">البريد الإلكتروني للمسؤول</label>
              <input 
                type="email" 
                value={email} 
                onChange={(e) => setEmail(e.target.value)} 
                className="w-full rounded-xl bg-black/40 border border-border/50 h-12 px-4 text-left font-bold outline-none focus:border-primary" 
                dir="ltr" 
                placeholder="admin@muawiya.edu" 
              />
            </div>
            <div className="space-y-2 text-right">
              <label className="text-xs font-bold text-muted-foreground mr-1">كلمة المرور</label>
              <div className="relative">
                <input 
                  type={showPassword ? "text" : "password"} 
                  value={password} 
                  onChange={(e) => setPassword(e.target.value)} 
                  className="w-full rounded-xl bg-black/40 border border-border/50 h-12 pr-4 pl-12 text-left outline-none focus:border-primary font-mono" 
                  dir="ltr" 
                />
                <button type="button" onClick={() => setShowPassword(!showPassword)} className="absolute left-4 top-1/2 -translate-y-1/2 text-muted-foreground/40">
                  {showPassword ? <EyeOff className="size-5" /> : <Eye className="size-5" />}
                </button>
              </div>
            </div>
            <Button type="submit" disabled={loading} className="w-full h-14 rounded-xl text-lg font-black shadow-lg">
              {loading ? <Loader2 className="animate-spin" /> : "دخول النظام السحابي"}
            </Button>
            
            {showSetup && (
              <div className="pt-4 space-y-4">
                <div className="relative">
                  <div className="absolute inset-0 flex items-center"><span className="w-full border-t border-border/50"></span></div>
                  <div className="relative flex justify-center text-[10px] uppercase"><span className="bg-background px-2 text-muted-foreground">خيارات الطوارئ للمشرف</span></div>
                </div>
                <Button type="button" onClick={handleForceAdmin} variant="outline" className="w-full border-green-600 text-green-600 hover:bg-green-600/10 h-14 rounded-xl font-black shadow-xl">
                  <ShieldAlert className="size-5 ml-2" />
                  تهيئة حساب مسؤول سحابي جديد
                </Button>
              </div>
            )}

            <div className="flex flex-col gap-4 text-center mt-6">
              <Link href="/forgot-password" global-attribute="recovery-link" className="text-xs text-primary/70 hover:text-primary font-bold">نسيت كلمة المرور؟</Link>
              <p className="text-xs text-muted-foreground">هل أنت معلم جديد؟ <Link href="/register" className="text-primary font-black hover:underline">سجل طلب انضمام</Link></p>
            </div>
          </form>
        </div>
      </div>
    </div>
  );
}
