
export type Role = 'ADMIN' | 'MANAGER' | 'DEPUTY_MANAGER' | 'SUPERVISOR' | 'TEACHER' | 'STUDENT';

export const ROLE_LABELS: Record<string, string> = {
  ADMIN: 'المشرف العام',
  MANAGER: 'مدير مركز',
  DEPUTY_MANAGER: 'نائب مدير',
  SUPERVISOR: 'مشرف حلقات',
  TEACHER: 'معلم',
  STUDENT: 'طالب'
};

export const PERFORMANCE_LABELS: Record<string, string> = {
  EXCELLENT: 'ممتاز',
  VERY_GOOD: 'جيد جداً',
  GOOD: 'جيد',
  REPEATED: 'مرجوع',
  NOT_COMMITTED: 'لم يلتزم'
};

export type PerformanceLevel = keyof typeof PERFORMANCE_LABELS;

export const QURAN_SURAHS = [
  "الفاتحة", "البقرة", "آل عمران", "النساء", "المائدة", "الأنعام", "الأعراف", "الأنفال", "التوبة", "يونس",
  "هود", "يوسف", "الرعد", "إبراهيم", "الحجر", "النحل", "الإسراء", "الكهف", "مريم", "طه",
  "الأنبياء", "الحج", "المؤمنون", "النور", "الفرقان", "الشعراء", "النمل", "القصص", "العنكبوت", "الروم",
  "لقمان", "السجدة", "الأحزاب", "سبأ", "فاطر", "يس", "الصافات", "ص", "الزمر", "غافر",
  "فصلت", "الشورى", "الزخرف", "الدخان", "الجاثية", "الأحقاف", "محمد", "الفتح", "الحجرات", "ق",
  "الذاريات", "الطور", "النجم", "القمر", "الرحمن", "الواقعة", "الحديد", "المجادلة", "الحشر", "الممتحنة",
  "الصف", "الجمعة", "المنافقون", "التغابن", "الطلاق", "التحريم", "الملك", "القلم", "الحاقة", "المعارج",
  "نوح", "الجن", "المزمل", "المدثر", "القيامة", "الإنسان", "المرسلات", "النبأ", "النازعات", "عبس",
  "التكوير", "الانفطار", "المطففين", "الانشقاق", "البروج", "الطارق", "الأعلى", "الغاشية", "الفجر", "البلد",
  "الشمس", "الليل", "الضحى", "الشرح", "التين", "العلق", "القدر", "البينة", "الزلزلة", "العاديات",
  "القارعة", "التكاثر", "العصر", "الهمزة", "الفيل", "قريش", "الماعون", "الكوثر", "الكافرون", "النصر",
  "المسد", "الإخلاص", "الفلق", "الناس"
];

export const maskEmail = (email: string) => {
  if (!email) return '';
  const [name, domain] = email.split('@');
  if (!name || !domain) return email;
  return `${name[0]}${name[1]}***@${domain}`;
};

export const isStudentHafiz = (start?: string, end?: string) => {
  if (!start || !end) return false;
  return (start === "الفاتحة" && end === "الناس") || (start === "الناس" && end === "الفاتحة");
};

export const getRemainingSurahs = (start?: string, end?: string) => {
  if (!start || !end) return QURAN_SURAHS;
  if (isStudentHafiz(start, end)) return [];
  const startIndex = QURAN_SURAHS.indexOf(start);
  const endIndex = QURAN_SURAHS.indexOf(end);
  if (startIndex === -1 || endIndex === -1) return QURAN_SURAHS;
  const min = Math.min(startIndex, endIndex);
  const max = Math.max(startIndex, endIndex);
  return QURAN_SURAHS.filter((_, index) => index < min || index > max);
};
