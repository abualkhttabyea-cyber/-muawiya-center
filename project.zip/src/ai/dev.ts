import { config } from 'dotenv';
config();

import '@/ai/flows/student-performance-insight.ts';