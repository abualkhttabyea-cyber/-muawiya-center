'use server';
/**
 * @fileOverview This file implements a Genkit flow for analyzing student performance in Quran memorization and revision.
 *
 * - studentPerformanceInsight - A function that analyzes student logs and generates a personalized performance summary.
 * - StudentPerformanceInsightInput - The input type for the studentPerformanceInsight function.
 * - StudentPerformanceInsightOutput - The return type for the studentPerformanceInsight function.
 */

import {ai} from '@/ai/genkit';
import {z} from 'genkit';

const MemorizationLogSchema = z.object({
  date: z.string().describe('The date of the memorization session (YYYY-MM-DD).'),
  surah: z.string().describe('The Surah (chapter) name or number memorized.'),
  ayahRange: z.string().describe('The range of Ayahs (verses) memorized.'),
  grade: z
    .number()
    .min(1)
    .max(5)
    .describe('A grade for the memorization quality (1=poor, 5=excellent).'),
});

const RevisionLogSchema = z.object({
  date: z.string().describe('The date of the revision session (YYYY-MM-DD).'),
  surah: z.string().describe('The Surah (chapter) name or number revised.'),
  ayahRange: z.string().describe('The range of Ayahs (verses) revised.'),
  grade: z
    .number()
    .min(1)
    .max(5)
    .describe('A grade for the revision quality (1=poor, 5=excellent).'),
});

const StudentPerformanceInsightInputSchema = z.object({
  studentName: z.string().describe("The student's name."),
  memorizationLogs: z.array(MemorizationLogSchema).describe('A list of memorization logs for the student.'),
  revisionLogs: z.array(RevisionLogSchema).describe('A list of revision logs for the student.'),
});
export type StudentPerformanceInsightInput = z.infer<typeof StudentPerformanceInsightInputSchema>;

const StudentPerformanceInsightOutputSchema = z.object({
  overallPerformanceSummary: z
    .string()
    .describe('A general summary of the student\u2019s overall performance in both memorization and revision.'),
  memorizationHighlights: z
    .array(z.string())
    .describe('Key observations and areas of strength or improvement in memorization.'),
  revisionHighlights: z
    .array(z.string())
    .describe('Key observations and areas of strength or improvement in revision.'),
  supportRecommendations: z
    .array(z.string())
    .describe('Specific recommendations for areas where the student might need additional support.'),
  commendations: z
    .array(z.string())
    .describe('Specific points for commendation and praise for the student\u2019s efforts.'),
});
export type StudentPerformanceInsightOutput = z.infer<typeof StudentPerformanceInsightOutputSchema>;

export async function studentPerformanceInsight(
  input: StudentPerformanceInsightInput
): Promise<StudentPerformanceInsightOutput> {
  return studentPerformanceInsightFlow(input);
}

const studentPerformancePrompt = ai.definePrompt({
  name: 'studentPerformancePrompt',
  input: {schema: StudentPerformanceInsightInputSchema},
  output: {schema: StudentPerformanceInsightOutputSchema},
  prompt: `You are an intelligent educational AI assistant specializing in Quranic studies. Your task is to analyze a student's memorization (Al-Hifz) and revision (Al-Muraja'a) logs to provide a comprehensive performance summary, identify areas for support, and offer commendations.

Analyze the provided data for student: {{{studentName}}}.

--- Memorization Logs (Al-Hifz) ---
{{#if memorizationLogs}}
{{#each memorizationLogs}}
Date: {{{date}}}, Surah: {{{surah}}}, Ayahs: {{{ayahRange}}}, Grade: {{{grade}}}
{{/each}}
{{else}}
No memorization logs available.
{{/if}}

--- Revision Logs (Al-Muraja'a) ---
{{#if revisionLogs}}
{{#each revisionLogs}}
Date: {{{date}}}, Surah: {{{surah}}}, Ayahs: {{{ayahRange}}}, Grade: {{{grade}}}
{{/each}}
{{else}}
No revision logs available.
{{/if}}

Based on the logs, provide the following:
1. An overall performance summary of the student, considering both memorization and revision.
2. Specific highlights and observations regarding their memorization progress and areas for improvement.
3. Specific highlights and observations regarding their revision consistency and areas for improvement.
4. Actionable recommendations for teachers or parents to support the student in challenging areas.
5. Points of commendation to acknowledge the student's efforts and successes.

Please format your response as a JSON object strictly adhering to the output schema.`,
});

const studentPerformanceInsightFlow = ai.defineFlow(
  {
    name: 'studentPerformanceInsightFlow',
    inputSchema: StudentPerformanceInsightInputSchema,
    outputSchema: StudentPerformanceInsightOutputSchema,
  },
  async input => {
    const {output} = await studentPerformancePrompt(input);
    return output!;
  }
);
