'use client';

/**
 * إعدادات الربط السحابي الرسمي لمركز معاويه لتحفيظ القران الكريم وعلومه.
 * تم تحديث البيانات بمفاتيح المشروع الحقيقية.
 */
export const firebaseConfig = {
  apiKey: "AIzaSyBz9JVHPAL7UQc3I0rRNvD7Yuw6Y1_21wM",
  authDomain: "moawiya-center.firebaseapp.com",
  projectId: "moawiya-center",
  storageBucket: "moawiya-center.firebasestorage.app",
  messagingSenderId: "347731690319",
  appId: "1:347731690319:web:23e35bf6f577c15521bb3a",
  measurementId: "G-3MTDYJMTF6"
};
