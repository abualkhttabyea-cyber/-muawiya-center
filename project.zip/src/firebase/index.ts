
'use client';

import { initializeApp, getApps, type FirebaseApp } from 'firebase/app';
import { getFirestore, type Firestore } from 'firebase/firestore';
import { getAuth, type Auth } from 'firebase/auth';
import { initializeAppCheck, ReCaptchaV3Provider } from 'firebase/app-check';
import { firebaseConfig } from './config';

/**
 * دالة تهيئة Firebase السحابية لمركز معاوية.
 * تم إضافة دعم App Check لحماية السحابة من الوصول غير المصرح به.
 */
export function initializeFirebase(): {
  app: FirebaseApp | null;
  db: Firestore | null;
  auth: Auth | null;
} {
  try {
    const app = getApps().length === 0 ? initializeApp(firebaseConfig) : getApps()[0];
    const db = getFirestore(app);
    const auth = getAuth(app);
    
    // تهيئة App Check - يتم تفعيلها باستخدام الـ Site Key من لوحة تحكم Firebase
    if (typeof window !== 'undefined') {
      // يمكنك وضع الـ Site Key الخاص بك في ملف .env تحت اسم NEXT_PUBLIC_RECAPTCHA_SITE_KEY
      const siteKey = process.env.NEXT_PUBLIC_RECAPTCHA_SITE_KEY; 
      if (siteKey) {
        initializeAppCheck(app, {
          provider: new ReCaptchaV3Provider(siteKey),
          isTokenAutoRefreshEnabled: true,
        });
      }
    }
    
    return { app, db, auth };
  } catch (error) {
    console.error("خطأ في الاتصال بالسحابة:", error);
    return { app: null, db: null, auth: null };
  }
}

export * from './provider';
export * from './client-provider';
export * from './firestore/use-collection';
export * from './firestore/use-doc';
export * from './auth/use-user';
